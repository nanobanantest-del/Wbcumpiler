import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar

plugins {
    java
    id("io.github.goooler.shadow") version "8.1.8"
}

group = "com.inventorysteal"
version = "1.0.0"
description = "InventorySteal - Team-based shared inventory plugin for PaperMC"

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // PaperMC API (compile-only — provided by the server at runtime)
    compileOnly("io.papermc.paper:paper-api:1.21.1-R0.1-SNAPSHOT")

    // SQLite JDBC driver — shaded into the plugin JAR
    implementation("org.xerial:sqlite-jdbc:3.45.3.0")

    // HikariCP connection pool — used for MySQL connections, shaded
    implementation("com.zaxxer:HikariCP:5.1.0")

    // MySQL Connector — shaded
    implementation("com.mysql:mysql-connector-j:8.3.0")
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.compilerArgs.add("-parameters")
}

tasks.withType<ShadowJar> {
    archiveClassifier.set("")

    // NOTE: SQLite JDBC uses JNI native libraries loaded by the original package
    // name "org.sqlite". Relocating it breaks the native-method binding, causing
    // UnsatisfiedLinkError at runtime. Do NOT relocate org.sqlite.
    //
    // NOTE: SLF4J is provided by the Paper server itself; shading/relocating it
    // causes the StaticLoggerBinder to be missing and produces SLF4J NOP warnings.
    // Do NOT relocate org.slf4j.

    // These are pure-Java libraries and safe to relocate:
    relocate("com.zaxxer.hikari", "com.inventorysteal.libs.hikari")
    relocate("com.mysql", "com.inventorysteal.libs.mysql")
    relocate("com.google.protobuf", "com.inventorysteal.libs.protobuf")
}

tasks.build {
    dependsOn(tasks.shadowJar)
}

tasks.processResources {
    val props = mapOf(
        "version" to version,
        "description" to description
    )
    inputs.properties(props)
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") {
        expand(props)
    }
}
