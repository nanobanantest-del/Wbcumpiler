package com.inventorysteal.manager;

import com.inventorysteal.model.Team;
import com.inventorysteal.util.SerializationUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages the team chest-storage GUI and the shared ender-chest inventory.
 *
 * <p>Opening and closing the team storage chest:
 * <ul>
 *   <li>When a player opens storage ({@link #openStorage}), a chest inventory
 *       is created (or reused) with the team's current storage contents.</li>
 *   <li>When all viewers close it, changes are flushed back to the team's
 *       {@code teamStorage} array and persisted.</li>
 * </ul>
 *
 * <p>The "syncing" lock set prevents recursive inventory-update loops when
 * the service pushes a canonical inventory into a player's inventory object.
 */
public class SharedInventoryManager {

    /** Players currently receiving a programmatic inventory update (lock set). */
    private final Set<UUID> syncingPlayers = ConcurrentHashMap.newKeySet();

    /**
     * Live team-storage inventories, keyed by team UUID.
     * Each {@link Inventory} is shared across all viewers of that team's storage.
     */
    private final Map<UUID, Inventory> openStorages = new HashMap<>();

    /** Reverse lookup: player UUID → team UUID (for inventory-close tracking). */
    private final Map<UUID, UUID> viewerToTeam = new HashMap<>();

    // -------------------------------------------------------------------------
    // Syncing lock
    // -------------------------------------------------------------------------

    /**
     * Mark a player as currently receiving a programmatic inventory sync.
     *
     * @param playerUUID player UUID
     */
    public void beginSync(UUID playerUUID) {
        syncingPlayers.add(playerUUID);
    }

    /**
     * Clear the syncing lock for a player.
     *
     * @param playerUUID player UUID
     */
    public void endSync(UUID playerUUID) {
        syncingPlayers.remove(playerUUID);
    }

    /**
     * @param playerUUID player UUID
     * @return {@code true} if this player is currently receiving a sync push
     */
    public boolean isSyncing(UUID playerUUID) {
        return syncingPlayers.contains(playerUUID);
    }

    // -------------------------------------------------------------------------
    // Team storage GUI
    // -------------------------------------------------------------------------

    /**
     * Open the team storage GUI for a player.
     *
     * @param player player who wants to open storage
     * @param team   their team
     */
    public void openStorage(Player player, Team team) {
        Inventory inv = openStorages.computeIfAbsent(team.getId(), id -> {
            String title = "§8[§6" + team.getName() + "§8] §r§lTeam Storage";
            Inventory chest = Bukkit.createInventory(null, team.getStorageSlots(), title);
            ItemStack[] stored = team.getTeamStorage();
            if (stored != null) {
                for (int i = 0; i < Math.min(stored.length, chest.getSize()); i++) {
                    chest.setItem(i, stored[i]);
                }
            }
            return chest;
        });
        player.openInventory(inv);
        viewerToTeam.put(player.getUniqueId(), team.getId());
    }

    /**
     * Called when a player closes their team-storage GUI.
     * If no more viewers remain, the inventory contents are flushed back to
     * the team model.
     *
     * @param player  player who closed the GUI
     * @param team    their team
     * @return {@code true} if this was the last viewer (data was flushed)
     */
    public boolean onStorageClosed(Player player, Team team) {
        viewerToTeam.remove(player.getUniqueId());

        Inventory inv = openStorages.get(team.getId());
        if (inv == null) return false;

        // Count remaining viewers of this inventory
        long viewers = viewerToTeam.values().stream()
                .filter(tid -> tid.equals(team.getId()))
                .count();

        if (viewers == 0) {
            // Flush inventory back to the team model
            ItemStack[] contents = inv.getContents();
            ItemStack[] copy = SerializationUtil.cloneArray(contents);
            team.setTeamStorage(copy);
            openStorages.remove(team.getId());
            return true;
        }
        return false;
    }

    /**
     * Expand the storage GUI for all current viewers when a Dragon-Egg upgrade
     * is applied.  Existing items are migrated to the new, larger inventory.
     *
     * @param team     team whose storage was upgraded
     * @param newSlots new slot count
     */
    public void expandStorage(Team team, int newSlots) {
        Inventory old = openStorages.remove(team.getId());

        String title = "§8[§6" + team.getName() + "§8] §r§lTeam Storage";
        Inventory expanded = Bukkit.createInventory(null, newSlots, title);

        if (old != null) {
            ItemStack[] oldContents = old.getContents();
            for (int i = 0; i < Math.min(oldContents.length, expanded.getSize()); i++) {
                expanded.setItem(i, oldContents[i]);
            }
            // Re-open the bigger inventory for any current viewers
            Set<UUID> viewers = new HashSet<>();
            for (Map.Entry<UUID, UUID> e : viewerToTeam.entrySet()) {
                if (e.getValue().equals(team.getId())) {
                    viewers.add(e.getKey());
                }
            }
            for (UUID viewerUUID : viewers) {
                Player viewer = Bukkit.getPlayer(viewerUUID);
                if (viewer != null && viewer.isOnline()) {
                    viewer.closeInventory();
                    viewer.openInventory(expanded);
                }
            }
        } else {
            // No viewers — just set the contents from the team model
            ItemStack[] stored = team.getTeamStorage();
            if (stored != null) {
                for (int i = 0; i < Math.min(stored.length, expanded.getSize()); i++) {
                    expanded.setItem(i, stored[i]);
                }
            }
        }

        openStorages.put(team.getId(), expanded);
    }

    /**
     * Close the storage GUI for all current viewers (e.g. on team disband or death).
     *
     * @param team team whose storage should be force-closed
     */
    public void forceCloseStorage(Team team) {
        openStorages.remove(team.getId());
        for (Iterator<Map.Entry<UUID, UUID>> it = viewerToTeam.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, UUID> e = it.next();
            if (e.getValue().equals(team.getId())) {
                Player viewer = Bukkit.getPlayer(e.getKey());
                if (viewer != null && viewer.isOnline()) {
                    viewer.closeInventory();
                }
                it.remove();
            }
        }
    }

    /**
     * Check whether the given {@link Inventory} object is a team-storage GUI.
     *
     * @param inv inventory to check
     * @return {@code true} if it is a live team-storage inventory
     */
    public boolean isTeamStorage(Inventory inv) {
        return openStorages.containsValue(inv);
    }

    /**
     * Find which team owns a given open storage inventory.
     *
     * @param inv inventory to look up
     * @return team UUID, or {@code null} if not found
     */
    public UUID getTeamForStorage(Inventory inv) {
        for (Map.Entry<UUID, Inventory> e : openStorages.entrySet()) {
            if (e.getValue().equals(inv)) return e.getKey();
        }
        return null;
    }
}
