package com.inventorysteal.manager;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;
import com.inventorysteal.repository.InventoryRepository;
import com.inventorysteal.repository.TeamRepository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * In-memory cache and primary access point for all {@link Team} data.
 *
 * <p>Teams are loaded from the database at startup and kept in three indexes:
 * <ul>
 *   <li>{@code byId} — keyed by team UUID</li>
 *   <li>{@code byName} — keyed by lowercase display name</li>
 *   <li>{@code byMember} — keyed by member player UUID</li>
 * </ul>
 *
 * <p>All mutating operations update both the in-memory indexes and the
 * persistent store atomically from the main server thread.
 */
public class TeamManager {

    private static final Logger LOGGER = Logger.getLogger(TeamManager.class.getName());

    private final TeamRepository teamRepository;
    private final InventoryRepository inventoryRepository;
    private final ConfigManager config;

    /** Primary cache: team-id → Team. */
    private final Map<UUID, Team> byId = new ConcurrentHashMap<>();

    /** Name index: lowercase name → Team. */
    private final Map<String, Team> byName = new ConcurrentHashMap<>();

    /** Member index: member UUID → Team. */
    private final Map<UUID, Team> byMember = new ConcurrentHashMap<>();

    public TeamManager(TeamRepository teamRepository,
                       InventoryRepository inventoryRepository,
                       ConfigManager config) {
        this.teamRepository = teamRepository;
        this.inventoryRepository = inventoryRepository;
        this.config = config;
    }

    // -------------------------------------------------------------------------
    // Startup
    // -------------------------------------------------------------------------

    /**
     * Load all teams from the database into memory.
     * Must be called once during plugin enable.
     */
    public void loadAll() {
        List<Team> teams = teamRepository.findAll();
        for (Team team : teams) {
            inventoryRepository.loadInventories(team);
            index(team);
        }
        LOGGER.info("Loaded " + teams.size() + " teams into cache.");
    }

    // -------------------------------------------------------------------------
    // Lookups
    // -------------------------------------------------------------------------

    /**
     * @param teamId team UUID
     * @return cached team, or {@code null}
     */
    public Team getTeam(UUID teamId) {
        return byId.get(teamId);
    }

    /**
     * @param name display name (case-insensitive)
     * @return cached team, or {@code null}
     */
    public Team getTeamByName(String name) {
        return byName.get(name.toLowerCase(Locale.ROOT));
    }

    /**
     * @param playerUUID player UUID
     * @return the team this player belongs to, or {@code null}
     */
    public Team getTeamByMember(UUID playerUUID) {
        return byMember.get(playerUUID);
    }

    /**
     * @return unmodifiable view of all cached teams
     */
    public Collection<Team> getAllTeams() {
        return Collections.unmodifiableCollection(byId.values());
    }

    /**
     * @param playerUUID player UUID
     * @return {@code true} if the player is in any team
     */
    public boolean isInTeam(UUID playerUUID) {
        return byMember.containsKey(playerUUID);
    }

    /** @return {@code true} if the given name is taken (case-insensitive). */
    public boolean teamNameExists(String name) {
        return byName.containsKey(name.toLowerCase(Locale.ROOT));
    }

    // -------------------------------------------------------------------------
    // Mutating operations
    // -------------------------------------------------------------------------

    /**
     * Create a new team with the given leader and persist it.
     *
     * @param name     display name (already validated by the caller)
     * @param leaderId UUID of the founding player
     * @return the newly created {@link Team}
     */
    public Team createTeam(String name, UUID leaderId) {
        Team team = new Team(UUID.randomUUID(), name, leaderId, config.getDefaultStorageSlots());
        team.addMember(leaderId);

        teamRepository.save(team);
        teamRepository.addMember(team.getId(), leaderId);

        index(team);
        LOGGER.fine("Team '" + name + "' created by " + leaderId);
        return team;
    }

    /**
     * Add a player to an existing team.
     *
     * @param team       target team
     * @param playerUUID player to add
     */
    public void addMember(Team team, UUID playerUUID) {
        team.addMember(playerUUID);
        teamRepository.addMember(team.getId(), playerUUID);
        byMember.put(playerUUID, team);
    }

    /**
     * Remove a player from their team.
     *
     * @param team       team they currently belong to
     * @param playerUUID player to remove
     */
    public void removeMember(Team team, UUID playerUUID) {
        team.removeMember(playerUUID);
        teamRepository.removeMember(team.getId(), playerUUID);
        byMember.remove(playerUUID);
    }

    /**
     * Disband a team, removing all members and deleting all persistent data.
     *
     * @param team team to disband
     */
    public void disbandTeam(Team team) {
        // Remove all member index entries
        for (UUID memberUUID : new ArrayList<>(team.getMembers())) {
            byMember.remove(memberUUID);
        }

        byId.remove(team.getId());
        byName.remove(team.getName().toLowerCase(Locale.ROOT));

        // Cascade-delete via DB (members, invites, inventories are FK-deleted)
        teamRepository.delete(team.getId());
        LOGGER.fine("Team '" + team.getName() + "' disbanded.");
    }

    /**
     * Persist in-memory changes to a team's metadata.
     *
     * @param team team to update
     */
    public void saveTeam(Team team) {
        teamRepository.update(team);
    }

    /**
     * Persist a new pending invite to the database.
     *
     * @param invite invite to store
     */
    public void saveInvite(PendingInvite invite) {
        teamRepository.addInvite(invite);
    }

    /**
     * Remove a pending invite from the database.
     *
     * @param teamId        team UUID
     * @param invitedPlayer invited player UUID
     */
    public void removeInvite(UUID teamId, UUID invitedPlayer) {
        teamRepository.removeInvite(teamId, invitedPlayer);
    }

    /**
     * Persist all inventory arrays for a team.
     *
     * @param team team to save
     */
    public void saveInventories(Team team) {
        inventoryRepository.saveInventories(team);
    }

    /**
     * Persist the storage upgrade for a team.
     *
     * @param team     team that was upgraded
     * @param newSlots new slot count
     */
    public void saveStorageUpgrade(Team team, int newSlots) {
        teamRepository.saveStorageSize(team.getId(), newSlots);
    }

    /**
     * Persist the health bonus for a team.
     *
     * @param team  team that gained health
     * @param bonus new bonus in HP
     */
    public void saveHealthBonus(Team team, double bonus) {
        teamRepository.saveMaxHealthBonus(team.getId(), bonus);
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    /**
     * Insert a team into all three in-memory indexes.
     *
     * @param team team to index
     */
    private void index(Team team) {
        byId.put(team.getId(), team);
        byName.put(team.getName().toLowerCase(Locale.ROOT), team);
        for (UUID member : team.getMembers()) {
            byMember.put(member, team);
        }
    }
}
