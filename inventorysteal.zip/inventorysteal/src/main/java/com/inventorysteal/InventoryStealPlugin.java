package com.inventorysteal;

import com.inventorysteal.command.InventoryStealCommand;
import com.inventorysteal.command.TeamAdminCommand;
import com.inventorysteal.command.TeamCommand;
import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.data.Database;
import com.inventorysteal.data.MySQLDatabase;
import com.inventorysteal.data.SQLiteDatabase;
import com.inventorysteal.listener.DeathListener;
import com.inventorysteal.listener.InventoryListener;
import com.inventorysteal.listener.PlayerListener;
import com.inventorysteal.listener.PotionListener;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.recipe.HeartRecipe;
import com.inventorysteal.repository.InventoryRepository;
import com.inventorysteal.repository.TeamRepository;
import com.inventorysteal.service.DeathService;
import com.inventorysteal.service.HealthSyncService;
import com.inventorysteal.service.InventorySyncService;
import com.inventorysteal.service.TeamService;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Objects;
import java.util.logging.Level;

/**
 * Main entry point for the InventorySteal plugin.
 *
 * <p>Wires up the full dependency graph:
 * <ol>
 *   <li>Save default configs.</li>
 *   <li>Initialise {@link ConfigManager} and {@link MessagesManager}.</li>
 *   <li>Initialise the {@link Database} and run schema migrations.</li>
 *   <li>Build repositories, managers, and services.</li>
 *   <li>Register event listeners and commands.</li>
 *   <li>Load all teams into memory.</li>
 *   <li>Register the Heart crafting recipe.</li>
 * </ol>
 */
public final class InventoryStealPlugin extends JavaPlugin {

    // -------------------------------------------------------------------------
    // Fields
    // -------------------------------------------------------------------------

    private ConfigManager configManager;
    private MessagesManager messagesManager;
    private Database database;
    private TeamManager teamManager;
    private SharedInventoryManager sharedInvManager;
    private InventorySyncService inventorySyncService;
    private HealthSyncService healthSyncService;
    private DeathService deathService;
    private TeamService teamService;
    private HeartRecipe heartRecipe;

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    public void onEnable() {
        getLogger().info("╔══════════════════════════════════╗");
        getLogger().info("║     InventorySteal v" + getDescription().getVersion() + "        ║");
        getLogger().info("║  Team-based shared inventory      ║");
        getLogger().info("╚══════════════════════════════════╝");

        // 1. Save bundled defaults if absent
        saveDefaultConfig();

        // 2. Config + Messages
        configManager = new ConfigManager(this);
        messagesManager = new MessagesManager(this);

        // 3. Database
        if (!initDatabase()) {
            getLogger().severe("Failed to initialise database. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // 4. Repositories
        TeamRepository teamRepository = new TeamRepository(database);
        InventoryRepository inventoryRepository = new InventoryRepository(database);

        // 5. Managers
        sharedInvManager = new SharedInventoryManager();
        teamManager = new TeamManager(teamRepository, inventoryRepository, configManager);

        // 6. Services (order matters — some services depend on others)
        inventorySyncService = new InventorySyncService(teamManager, sharedInvManager, configManager, this);
        healthSyncService = new HealthSyncService(teamManager, sharedInvManager, configManager, this);
        deathService = new DeathService(teamManager, sharedInvManager, configManager, messagesManager, this);
        teamService = new TeamService(
            teamManager, inventorySyncService, healthSyncService,
            configManager, messagesManager, this
        );

        // 7. Heart recipe
        heartRecipe = new HeartRecipe(this, teamManager, healthSyncService, configManager, messagesManager);
        if (configManager.isHeartRecipeEnabled()) {
            heartRecipe.register();
        }

        // 8. Register event listeners
        registerListeners();

        // 9. Register commands
        registerCommands();

        // 10. Load all teams from DB into memory
        teamManager.loadAll();

        getLogger().info("InventorySteal enabled successfully.");
    }

    @Override
    public void onDisable() {
        // Save all in-memory team inventories before shutdown
        if (teamManager != null) {
            for (var team : teamManager.getAllTeams()) {
                teamManager.saveInventories(team);
            }
            getLogger().info("Saved all team inventories.");
        }

        // Unregister recipe
        if (heartRecipe != null && configManager != null && configManager.isHeartRecipeEnabled()) {
            heartRecipe.unregister();
        }

        // Close DB connection
        if (database != null) {
            database.close();
            getLogger().info("Database connection closed.");
        }

        getLogger().info("InventorySteal disabled.");
    }

    // -------------------------------------------------------------------------
    // Initialisation helpers
    // -------------------------------------------------------------------------

    /**
     * Initialise and connect to the configured database.
     *
     * @return {@code true} if initialisation succeeded
     */
    private boolean initDatabase() {
        String type = configManager.getDbType();
        if ("mysql".equalsIgnoreCase(type)) {
            database = new MySQLDatabase(
                configManager.getMysqlHost(),
                configManager.getMysqlPort(),
                configManager.getMysqlDatabase(),
                configManager.getMysqlUsername(),
                configManager.getMysqlPassword(),
                configManager.getMysqlPoolSize(),
                configManager.getMysqlConnectionTimeout(),
                configManager.getMysqlIdleTimeout(),
                configManager.getMysqlMaxLifetime()
            );
        } else {
            File dbFile = new File(getDataFolder(), configManager.getSqliteFile());
            database = new SQLiteDatabase(dbFile);
        }

        try {
            database.initialize();
            getLogger().info("Database initialised (" + type.toUpperCase() + ").");
            return true;
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Database initialisation failed: " + e.getMessage(), e);
            return false;
        }
    }

    /**
     * Register all Bukkit event listeners.
     */
    private void registerListeners() {
        PluginManager pm = getServer().getPluginManager();

        pm.registerEvents(new InventoryListener(
            teamManager, sharedInvManager, inventorySyncService, this), this);

        pm.registerEvents(new PlayerListener(
            teamManager, sharedInvManager, inventorySyncService, healthSyncService, configManager, this), this);

        pm.registerEvents(new DeathListener(
            teamManager, sharedInvManager, deathService, inventorySyncService, this), this);

        pm.registerEvents(new PotionListener(
            teamManager, sharedInvManager, configManager, this), this);

        // Heart recipe right-click listener
        pm.registerEvents(heartRecipe, this);

        getLogger().info("Listeners registered.");
    }

    /**
     * Register all plugin commands.
     */
    private void registerCommands() {
        TeamCommand teamCmd = new TeamCommand(
            teamManager, sharedInvManager, teamService,
            inventorySyncService, healthSyncService, messagesManager);

        TeamAdminCommand teamAdminCmd = new TeamAdminCommand(
            teamManager, sharedInvManager, healthSyncService, inventorySyncService, messagesManager);

        InventoryStealCommand isCmd = new InventoryStealCommand(this, messagesManager);

        Objects.requireNonNull(getCommand("team")).setExecutor(teamCmd);
        Objects.requireNonNull(getCommand("team")).setTabCompleter(teamCmd);
        Objects.requireNonNull(getCommand("teamadmin")).setExecutor(teamAdminCmd);
        Objects.requireNonNull(getCommand("teamadmin")).setTabCompleter(teamAdminCmd);
        Objects.requireNonNull(getCommand("inventorysteal")).setExecutor(isCmd);
        Objects.requireNonNull(getCommand("inventorysteal")).setTabCompleter(isCmd);

        getLogger().info("Commands registered.");
    }

    // -------------------------------------------------------------------------
    // Public accessors (used by commands that need to call reload)
    // -------------------------------------------------------------------------

    /** @return the live {@link ConfigManager} instance */
    public ConfigManager getConfigManager() { return configManager; }

    /** @return the live {@link MessagesManager} instance */
    public MessagesManager getMessagesManager() { return messagesManager; }

    /** @return the {@link HeartRecipe} manager */
    public HeartRecipe getHeartRecipe() { return heartRecipe; }

    /** @return the active {@link TeamManager} */
    public TeamManager getTeamManager() { return teamManager; }

    /** @return the active {@link HealthSyncService} */
    public HealthSyncService getHealthSyncService() { return healthSyncService; }
}
