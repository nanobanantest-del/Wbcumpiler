package com.inventorysteal.recipe;

import com.inventorysteal.InventoryStealPlugin;
import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.service.HealthSyncService;
import com.inventorysteal.util.ItemUtil;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Manages the Heart item crafting recipe and its right-click consume behavior.
 *
 * <h3>Recipe</h3>
 * <pre>
 * G G G        G = Gold Block
 * D B D        D = Diamond Block, B = Beacon
 * N N N        N = Netherite Block
 * </pre>
 *
 * <p>Right-clicking with a Heart increases the team's max health by +2 HP (1 heart).
 */
public class HeartRecipe implements Listener {

    private static final Logger LOGGER = Logger.getLogger(HeartRecipe.class.getName());

    private static final NamespacedKey RECIPE_KEY = new NamespacedKey("inventorysteal", "heart");

    private final InventoryStealPlugin plugin;
    private final TeamManager teamManager;
    private final HealthSyncService healthSyncService;
    private final ConfigManager config;
    private final MessagesManager messages;

    private ItemStack heartItem;
    private boolean registered = false;

    public HeartRecipe(InventoryStealPlugin plugin,
                       TeamManager teamManager,
                       HealthSyncService healthSyncService,
                       ConfigManager config,
                       MessagesManager messages) {
        this.plugin = plugin;
        this.teamManager = teamManager;
        this.healthSyncService = healthSyncService;
        this.config = config;
        this.messages = messages;
        buildHeartItem();
    }

    // -------------------------------------------------------------------------
    // Item creation
    // -------------------------------------------------------------------------

    /**
     * Construct the Heart item from config values.
     */
    private void buildHeartItem() {
        List<String> lore = messages.getList("heart.item-lore");
        String name = messages.formatRaw("heart.item-name", Map.of());

        heartItem = ItemUtil.buildItemWithModel(
            Material.RED_DYE,
            name,
            lore,
            config.getHeartCustomModelData()
        );
    }

    /**
     * @return a fresh clone of the Heart item
     */
    public ItemStack getHeartItem() {
        return heartItem.clone();
    }

    // -------------------------------------------------------------------------
    // Recipe registration
    // -------------------------------------------------------------------------

    /**
     * Register the shaped crafting recipe with the server.
     * Safe to call multiple times — unregisters before re-registering.
     */
    public void register() {
        if (registered) unregister();

        buildHeartItem(); // refresh item in case config was reloaded

        ShapedRecipe recipe = new ShapedRecipe(RECIPE_KEY, heartItem);
        recipe.shape("GGG", "DBD", "NNN");
        recipe.setIngredient('G', Material.GOLD_BLOCK);
        recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        recipe.setIngredient('B', Material.BEACON);
        recipe.setIngredient('N', Material.NETHERITE_BLOCK);

        plugin.getServer().addRecipe(recipe);
        registered = true;
        LOGGER.info("Heart recipe registered.");
    }

    /**
     * Remove the crafting recipe from the server.
     */
    public void unregister() {
        plugin.getServer().removeRecipe(RECIPE_KEY);
        registered = false;
        LOGGER.info("Heart recipe unregistered.");
    }

    // -------------------------------------------------------------------------
    // Right-click handler
    // -------------------------------------------------------------------------

    /**
     * Consume a Heart item when a player right-clicks with it, increasing the
     * team's max health by the configured amount.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        // Right click only (in air or on block)
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                && event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null || item.getType() == Material.AIR) return;
        if (!isHeartItem(item)) return;

        event.setCancelled(true);

        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) {
            player.sendMessage(messages.get("heart.not-in-team"));
            return;
        }

        // Check max health limit
        double limit = config.getMaxHealthBonus();
        if (limit > 0 && team.getMaxHealthBonus() + config.getHpPerHeart() > limit) {
            player.sendMessage(messages.get("heart.max-reached"));
            return;
        }

        // Consume one item from the hand
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            event.getPlayer().getInventory().setItemInMainHand(null);
        }

        // Add health to the team
        healthSyncService.addHeart(team);

        // Broadcast
        double totalHp = 20.0 + team.getMaxHealthBonus();
        teamManager.getAllTeams(); // just to keep the reference alive

        String broadcastMsg = messages.format("heart.used-broadcast", Map.of(
            "player", player.getName(),
            "health", String.valueOf(totalHp)
        ));
        for (java.util.UUID memberUUID : team.getMembers()) {
            Player member = plugin.getServer().getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                if (member.getUniqueId().equals(player.getUniqueId())) {
                    member.sendMessage(messages.get("heart.used"));
                } else {
                    member.sendMessage(broadcastMsg);
                }
                playSoundAndParticles(member);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Check whether an item is the Heart item by comparing material and display name.
     *
     * @param item item to check
     * @return {@code true} if this is a Heart item
     */
    private boolean isHeartItem(ItemStack item) {
        if (item.getType() != Material.RED_DYE) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        // Check display name
        ItemMeta heartMeta = heartItem.getItemMeta();
        if (heartMeta == null) return false;
        if (!meta.getDisplayName().equals(heartMeta.getDisplayName())) return false;
        // Check custom model data
        if (config.getHeartCustomModelData() > 0) {
            return meta.getCustomModelData() == heartMeta.getCustomModelData();
        }
        return true;
    }

    private void playSoundAndParticles(Player player) {
        if (config.isSoundsEnabled()) {
            try {
                Sound sound = Sound.valueOf(config.getSoundHeartUse());
                player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
            } catch (IllegalArgumentException e) {
                LOGGER.warning("Invalid heart-use sound: " + config.getSoundHeartUse());
            }
        }

        if (config.isParticlesEnabled()) {
            player.getWorld().spawnParticle(
                Particle.HEART, player.getLocation().add(0, 1.5, 0), 10,
                0.5, 0.5, 0.5, 0.1
            );
        }
    }
}
