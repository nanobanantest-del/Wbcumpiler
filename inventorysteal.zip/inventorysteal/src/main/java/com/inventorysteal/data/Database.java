package com.inventorysteal.data;

import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Database abstraction used by the repository layer.
 *
 * <p>All methods run on the calling thread.  Callers are responsible for
 * ensuring that write methods are only called from the main server thread
 * (or from an async task that has been explicitly designed to be thread-safe).
 *
 * <p>Implementations: {@link SQLiteDatabase}, {@link MySQLDatabase}.
 */
public interface Database {

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    /**
     * Initialise the connection / pool and run schema migrations.
     * Must be called once before any other method.
     *
     * @throws Exception if initialisation fails
     */
    void initialize() throws Exception;

    /** Close the connection / pool cleanly. */
    void close();

    // -------------------------------------------------------------------------
    // Team CRUD
    // -------------------------------------------------------------------------

    /**
     * Persist a brand-new team.
     *
     * @param team fully initialised {@link Team} object
     */
    void createTeam(Team team);

    /**
     * Load a team by its UUID.
     *
     * @param teamId team UUID
     * @return loaded team, or {@code null} if not found
     */
    Team getTeam(UUID teamId);

    /**
     * Load a team by its display name (case-insensitive).
     *
     * @param name team display name
     * @return loaded team, or {@code null} if not found
     */
    Team getTeamByName(String name);

    /**
     * Find the team that a given player belongs to.
     *
     * @param playerUUID player UUID
     * @return the player's team, or {@code null} if not in a team
     */
    Team getTeamByMember(UUID playerUUID);

    /**
     * Load all teams (used for list command and startup pre-caching).
     *
     * @return unmodifiable list of all teams
     */
    List<Team> getAllTeams();

    /**
     * Persist in-memory changes to a team's metadata (name, leader, health
     * bonus, storage slots).  Does <em>not</em> save inventory data — use
     * {@link #saveTeamInventory} for that.
     *
     * @param team team to update
     */
    void updateTeam(Team team);

    /**
     * Delete a team and all associated data (members, invites, inventory).
     *
     * @param teamId team UUID
     */
    void deleteTeam(UUID teamId);

    // -------------------------------------------------------------------------
    // Member management
    // -------------------------------------------------------------------------

    /**
     * Add a member to a team.
     *
     * @param teamId     team UUID
     * @param playerUUID new member UUID
     */
    void addMember(UUID teamId, UUID playerUUID);

    /**
     * Remove a member from a team.
     *
     * @param teamId     team UUID
     * @param playerUUID member to remove
     */
    void removeMember(UUID teamId, UUID playerUUID);

    /**
     * Load all member UUIDs for a team.
     *
     * @param teamId team UUID
     * @return list of member UUIDs
     */
    List<UUID> getMembers(UUID teamId);

    // -------------------------------------------------------------------------
    // Invite management
    // -------------------------------------------------------------------------

    /**
     * Persist a new pending invite.
     *
     * @param invite invite to store
     */
    void addInvite(PendingInvite invite);

    /**
     * Remove a pending invite.
     *
     * @param teamId        team UUID
     * @param invitedPlayer invited player UUID
     */
    void removeInvite(UUID teamId, UUID invitedPlayer);

    /**
     * Load all pending invites for a team.
     *
     * @param teamId team UUID
     * @return map of invited-player UUID → {@link PendingInvite}
     */
    Map<UUID, PendingInvite> getInvites(UUID teamId);

    // -------------------------------------------------------------------------
    // Inventory storage
    // -------------------------------------------------------------------------

    /**
     * Persist all inventory data for a team.
     *
     * @param teamId              team UUID
     * @param playerInventory     Base64-serialised canonical player-inventory
     * @param enderChestData      Base64-serialised shared ender-chest
     * @param teamStorageData     Base64-serialised team chest-storage
     */
    void saveTeamInventory(UUID teamId,
                           String playerInventory,
                           String enderChestData,
                           String teamStorageData);

    /**
     * Load all inventory data for a team.
     *
     * @param teamId team UUID
     * @return string array [playerInventory, enderChestData, teamStorageData],
     *         or {@code null} if no row exists yet
     */
    String[] getTeamInventory(UUID teamId);

    // -------------------------------------------------------------------------
    // Upgrade persistence
    // -------------------------------------------------------------------------

    /**
     * Persist the team's current storage slot count.
     *
     * @param teamId team UUID
     * @param slots  new slot count
     */
    void saveStorageSize(UUID teamId, int slots);

    /**
     * Persist the team's accumulated max-health bonus.
     *
     * @param teamId team UUID
     * @param bonus  health bonus in HP (2 HP = 1 heart)
     */
    void saveMaxHealthBonus(UUID teamId, double bonus);
}
