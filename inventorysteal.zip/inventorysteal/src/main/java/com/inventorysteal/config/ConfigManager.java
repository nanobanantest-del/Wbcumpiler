package com.inventorysteal.config;

import com.inventorysteal.InventoryStealPlugin;
import org.bukkit.configuration.file.FileConfiguration;

/**
 * Strongly-typed wrapper around {@code config.yml}.
 *
 * <p>Call {@link #reload()} after {@link InventoryStealPlugin#reloadConfig()} to
 * refresh the cached values.
 */
public class ConfigManager {

    private final InventoryStealPlugin plugin;

    // Database
    private String dbType;
    private String sqliteFile;
    private String mysqlHost;
    private int mysqlPort;
    private String mysqlDatabase;
    private String mysqlUsername;
    private String mysqlPassword;
    private int mysqlPoolSize;
    private long mysqlConnectionTimeout;
    private long mysqlIdleTimeout;
    private long mysqlMaxLifetime;

    // Team settings
    private int maxTeamSize;
    private int inviteTimeout;
    private int cooldownCreate;
    private int cooldownLeave;
    private int cooldownDisband;

    // Inventory
    private boolean syncMain;
    private boolean syncArmor;
    private boolean syncOffhand;
    private boolean syncEnderChest;
    private int defaultStorageSlots;
    private int slotsPerUpgrade;
    private int maxStorageSlots;
    private String upgradeItem;

    // Health
    private boolean syncHealth;
    private boolean syncHunger;
    private boolean syncSaturation;
    private boolean syncAir;
    private boolean syncFireTicks;
    private double maxHealthBonus;

    // Death
    private boolean teamDeath;
    private boolean dropInventories;
    private boolean clearSharedInventory;

    // Heart
    private boolean heartRecipeEnabled;
    private int heartCustomModelData;
    private double hpPerHeart;

    // Sounds & Particles
    private boolean soundsEnabled;
    private boolean particlesEnabled;
    private String soundTeamCreate;
    private String soundTeamJoin;
    private String soundTeamLeave;
    private String soundTeamDeath;
    private String soundHeartUse;
    private String soundStorageUpgrade;

    public ConfigManager(InventoryStealPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    /** Re-read all values from the current in-memory config. */
    public void reload() {
        FileConfiguration cfg = plugin.getConfig();

        // Database
        dbType = cfg.getString("database.type", "sqlite").toLowerCase();
        sqliteFile = cfg.getString("database.sqlite.file", "inventorysteal.db");
        mysqlHost = cfg.getString("database.mysql.host", "localhost");
        mysqlPort = cfg.getInt("database.mysql.port", 3306);
        mysqlDatabase = cfg.getString("database.mysql.database", "inventorysteal");
        mysqlUsername = cfg.getString("database.mysql.username", "root");
        mysqlPassword = cfg.getString("database.mysql.password", "password");
        mysqlPoolSize = cfg.getInt("database.mysql.pool-size", 10);
        mysqlConnectionTimeout = cfg.getLong("database.mysql.connection-timeout", 30000L);
        mysqlIdleTimeout = cfg.getLong("database.mysql.idle-timeout", 600000L);
        mysqlMaxLifetime = cfg.getLong("database.mysql.max-lifetime", 1800000L);

        // Team
        maxTeamSize = cfg.getInt("team.max-size", 10);
        inviteTimeout = cfg.getInt("team.invite-timeout", 60);
        cooldownCreate = cfg.getInt("team.cooldown.create", 30);
        cooldownLeave = cfg.getInt("team.cooldown.leave", 60);
        cooldownDisband = cfg.getInt("team.cooldown.disband", 120);

        // Inventory
        syncMain = cfg.getBoolean("inventory.sync-main", true);
        syncArmor = cfg.getBoolean("inventory.sync-armor", true);
        syncOffhand = cfg.getBoolean("inventory.sync-offhand", true);
        syncEnderChest = cfg.getBoolean("inventory.sync-ender-chest", true);
        defaultStorageSlots = cfg.getInt("inventory.default-storage-slots", 27);
        slotsPerUpgrade = cfg.getInt("inventory.slots-per-upgrade", 27);
        maxStorageSlots = cfg.getInt("inventory.max-storage-slots", 0);
        upgradeItem = cfg.getString("inventory.upgrade-item", "DRAGON_EGG");

        // Health
        syncHealth = cfg.getBoolean("health.sync-health", true);
        syncHunger = cfg.getBoolean("health.sync-hunger", true);
        syncSaturation = cfg.getBoolean("health.sync-saturation", true);
        syncAir = cfg.getBoolean("health.sync-air", true);
        syncFireTicks = cfg.getBoolean("health.sync-fire-ticks", true);
        maxHealthBonus = cfg.getDouble("health.max-health-bonus", 0.0);

        // Death
        teamDeath = cfg.getBoolean("death.team-death", true);
        dropInventories = cfg.getBoolean("death.drop-inventories", true);
        clearSharedInventory = cfg.getBoolean("death.clear-shared-inventory", true);

        // Heart
        heartRecipeEnabled = cfg.getBoolean("heart.recipe-enabled", true);
        heartCustomModelData = cfg.getInt("heart.custom-model-data", 0);
        hpPerHeart = cfg.getDouble("heart.hp-per-heart", 2.0);

        // Sounds
        soundsEnabled = cfg.getBoolean("sounds.enabled", true);
        soundTeamCreate = cfg.getString("sounds.team-create", "ENTITY_PLAYER_LEVELUP");
        soundTeamJoin = cfg.getString("sounds.team-join", "ENTITY_EXPERIENCE_ORB_PICKUP");
        soundTeamLeave = cfg.getString("sounds.team-leave", "BLOCK_NOTE_BLOCK_BASS");
        soundTeamDeath = cfg.getString("sounds.team-death", "ENTITY_WITHER_SPAWN");
        soundHeartUse = cfg.getString("sounds.heart-use", "ENTITY_PLAYER_LEVELUP");
        soundStorageUpgrade = cfg.getString("sounds.storage-upgrade", "BLOCK_ANVIL_USE");

        // Particles
        particlesEnabled = cfg.getBoolean("particles.enabled", true);
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public String getDbType() { return dbType; }

    public String getSqliteFile() { return sqliteFile; }

    public String getMysqlHost() { return mysqlHost; }
    public int getMysqlPort() { return mysqlPort; }
    public String getMysqlDatabase() { return mysqlDatabase; }
    public String getMysqlUsername() { return mysqlUsername; }
    public String getMysqlPassword() { return mysqlPassword; }
    public int getMysqlPoolSize() { return mysqlPoolSize; }
    public long getMysqlConnectionTimeout() { return mysqlConnectionTimeout; }
    public long getMysqlIdleTimeout() { return mysqlIdleTimeout; }
    public long getMysqlMaxLifetime() { return mysqlMaxLifetime; }

    public int getMaxTeamSize() { return maxTeamSize; }
    public int getInviteTimeout() { return inviteTimeout; }
    public int getCooldownCreate() { return cooldownCreate; }
    public int getCooldownLeave() { return cooldownLeave; }
    public int getCooldownDisband() { return cooldownDisband; }

    public boolean isSyncMain() { return syncMain; }
    public boolean isSyncArmor() { return syncArmor; }
    public boolean isSyncOffhand() { return syncOffhand; }
    public boolean isSyncEnderChest() { return syncEnderChest; }
    public int getDefaultStorageSlots() { return defaultStorageSlots; }
    public int getSlotsPerUpgrade() { return slotsPerUpgrade; }
    public int getMaxStorageSlots() { return maxStorageSlots; }
    public String getUpgradeItem() { return upgradeItem; }

    public boolean isSyncHealth() { return syncHealth; }
    public boolean isSyncHunger() { return syncHunger; }
    public boolean isSyncSaturation() { return syncSaturation; }
    public boolean isSyncAir() { return syncAir; }
    public boolean isSyncFireTicks() { return syncFireTicks; }
    /** Maximum total health bonus in HP (0 = unlimited). */
    public double getMaxHealthBonus() { return maxHealthBonus; }

    public boolean isTeamDeath() { return teamDeath; }
    public boolean isDropInventories() { return dropInventories; }
    public boolean isClearSharedInventory() { return clearSharedInventory; }

    public boolean isHeartRecipeEnabled() { return heartRecipeEnabled; }
    public int getHeartCustomModelData() { return heartCustomModelData; }
    public double getHpPerHeart() { return hpPerHeart; }

    public boolean isSoundsEnabled() { return soundsEnabled; }
    public boolean isParticlesEnabled() { return particlesEnabled; }
    public String getSoundTeamCreate() { return soundTeamCreate; }
    public String getSoundTeamJoin() { return soundTeamJoin; }
    public String getSoundTeamLeave() { return soundTeamLeave; }
    public String getSoundTeamDeath() { return soundTeamDeath; }
    public String getSoundHeartUse() { return soundHeartUse; }
    public String getSoundStorageUpgrade() { return soundStorageUpgrade; }
}
