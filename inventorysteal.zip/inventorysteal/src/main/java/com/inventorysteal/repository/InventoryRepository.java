package com.inventorysteal.repository;

import com.inventorysteal.data.Database;
import com.inventorysteal.model.Team;
import com.inventorysteal.util.SerializationUtil;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Repository responsible for persisting and loading all inventory data
 * associated with a {@link Team}.
 *
 * <p>Inventory data is serialised to Base64 by {@link SerializationUtil} before
 * being handed to the database layer.
 */
public class InventoryRepository {

    private static final Logger LOGGER = Logger.getLogger(InventoryRepository.class.getName());

    private final Database database;

    /**
     * @param database the active database implementation
     */
    public InventoryRepository(Database database) {
        this.database = database;
    }

    // -------------------------------------------------------------------------
    // Persistence
    // -------------------------------------------------------------------------

    /**
     * Persist all inventory arrays for a team to the database.
     *
     * @param team team whose inventories should be saved
     */
    public void saveInventories(Team team) {
        String playerInv = SerializationUtil.serializeItemArray(team.getCanonicalInventory());
        String enderChest = SerializationUtil.serializeItemArray(team.getSharedEnderChest());
        String storage = SerializationUtil.serializeItemArray(team.getTeamStorage());
        database.saveTeamInventory(team.getId(), playerInv, enderChest, storage);
    }

    /**
     * Load all inventory arrays for a team from the database and inject them
     * into the in-memory {@link Team} object.
     *
     * @param team team to populate
     */
    public void loadInventories(Team team) {
        String[] data = database.getTeamInventory(team.getId());
        if (data == null) {
            // No inventory row yet — leave arrays empty
            return;
        }

        if (data[0] != null) {
            ItemStack[] playerInv = SerializationUtil.deserializeItemArray(data[0]);
            if (playerInv != null) team.setCanonicalInventory(playerInv);
        }

        if (data[1] != null) {
            ItemStack[] enderChest = SerializationUtil.deserializeItemArray(data[1]);
            if (enderChest != null) team.setSharedEnderChest(enderChest);
        }

        if (data[2] != null) {
            // Team storage may have grown — ensure the array matches the stored slot count
            ItemStack[] storage = SerializationUtil.deserializeItemArray(data[2]);
            if (storage != null) {
                if (storage.length != team.getStorageSlots()) {
                    // Resize to current slot count (expand or trim)
                    ItemStack[] resized = new ItemStack[team.getStorageSlots()];
                    System.arraycopy(storage, 0, resized, 0, Math.min(storage.length, resized.length));
                    storage = resized;
                }
                team.setTeamStorage(storage);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Selective saves
    // -------------------------------------------------------------------------

    /**
     * Persist only the canonical player inventory.
     *
     * @param team team to save from
     */
    public void savePlayerInventory(Team team) {
        // Re-save all three as a single DB row
        saveInventories(team);
    }

    /**
     * Persist only the ender-chest inventory.
     *
     * @param team team to save from
     */
    public void saveEnderChest(Team team) {
        saveInventories(team);
    }

    /**
     * Persist only the team storage inventory.
     *
     * @param team team to save from
     */
    public void saveTeamStorage(Team team) {
        saveInventories(team);
    }
}
