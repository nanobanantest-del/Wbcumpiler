package com.inventorysteal.repository;

import com.inventorysteal.data.Database;
import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Repository for {@link Team} persistence.
 *
 * <p>Acts as a thin façade over {@link Database} so that services and managers
 * only depend on this higher-level abstraction and are not coupled to specific
 * SQL dialects.
 */
public class TeamRepository {

    private final Database database;

    /**
     * @param database the active database implementation
     */
    public TeamRepository(Database database) {
        this.database = database;
    }

    // -------------------------------------------------------------------------
    // CRUD
    // -------------------------------------------------------------------------

    /**
     * Persist a newly created team.
     *
     * @param team fully initialised team
     */
    public void save(Team team) {
        database.createTeam(team);
    }

    /**
     * Overwrite persistent team metadata.
     *
     * @param team team with updated fields
     */
    public void update(Team team) {
        database.updateTeam(team);
    }

    /**
     * Remove a team and all associated data.
     *
     * @param teamId team UUID
     */
    public void delete(UUID teamId) {
        database.deleteTeam(teamId);
    }

    /**
     * Find a team by its stable UUID.
     *
     * @param teamId team UUID
     * @return team, or {@code null} if not found
     */
    public Team findById(UUID teamId) {
        return database.getTeam(teamId);
    }

    /**
     * Find a team by its display name (case-insensitive).
     *
     * @param name team name
     * @return team, or {@code null} if not found
     */
    public Team findByName(String name) {
        return database.getTeamByName(name);
    }

    /**
     * Find the team a player belongs to.
     *
     * @param playerUUID player UUID
     * @return team, or {@code null} if player has no team
     */
    public Team findByMember(UUID playerUUID) {
        return database.getTeamByMember(playerUUID);
    }

    /**
     * Load every team (used at startup for cache warming).
     *
     * @return all teams
     */
    public List<Team> findAll() {
        return database.getAllTeams();
    }

    // -------------------------------------------------------------------------
    // Member management
    // -------------------------------------------------------------------------

    /**
     * Add a member row to the database.
     *
     * @param teamId     team UUID
     * @param playerUUID new member UUID
     */
    public void addMember(UUID teamId, UUID playerUUID) {
        database.addMember(teamId, playerUUID);
    }

    /**
     * Remove a member row from the database.
     *
     * @param teamId     team UUID
     * @param playerUUID member to remove
     */
    public void removeMember(UUID teamId, UUID playerUUID) {
        database.removeMember(teamId, playerUUID);
    }

    // -------------------------------------------------------------------------
    // Invite management
    // -------------------------------------------------------------------------

    /**
     * Persist a new invite.
     *
     * @param invite invite to store
     */
    public void addInvite(PendingInvite invite) {
        database.addInvite(invite);
    }

    /**
     * Remove an invite.
     *
     * @param teamId        team UUID
     * @param invitedPlayer invited player UUID
     */
    public void removeInvite(UUID teamId, UUID invitedPlayer) {
        database.removeInvite(teamId, invitedPlayer);
    }

    /**
     * Load all invites for a team.
     *
     * @param teamId team UUID
     * @return map of invited-player UUID → invite
     */
    public Map<UUID, PendingInvite> getInvites(UUID teamId) {
        return database.getInvites(teamId);
    }

    // -------------------------------------------------------------------------
    // Upgrade persistence
    // -------------------------------------------------------------------------

    /**
     * Persist an updated storage slot count.
     *
     * @param teamId team UUID
     * @param slots  new slot count
     */
    public void saveStorageSize(UUID teamId, int slots) {
        database.saveStorageSize(teamId, slots);
    }

    /**
     * Persist an updated max-health bonus.
     *
     * @param teamId team UUID
     * @param bonus  bonus HP
     */
    public void saveMaxHealthBonus(UUID teamId, double bonus) {
        database.saveMaxHealthBonus(teamId, bonus);
    }
}
