package com.inventorysteal.listener;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.service.HealthSyncService;
import com.inventorysteal.service.InventorySyncService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.*;

/**
 * Handles player-level events for health, hunger, air, fire and login/logout.
 *
 * <p>On join: the player's inventory and health are pushed from the canonical
 * team snapshot so they start in sync even if they were offline when their
 * teammates made changes.
 * On quit: the current inventory state is captured before the player disconnects.
 */
public class PlayerListener implements Listener {

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final InventorySyncService inventorySyncService;
    private final HealthSyncService healthSyncService;
    private final ConfigManager config;
    private final org.bukkit.plugin.java.JavaPlugin plugin;

    public PlayerListener(TeamManager teamManager,
                          SharedInventoryManager sharedInvManager,
                          InventorySyncService inventorySyncService,
                          HealthSyncService healthSyncService,
                          ConfigManager config,
                          org.bukkit.plugin.java.JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.inventorySyncService = inventorySyncService;
        this.healthSyncService = healthSyncService;
        this.config = config;
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Login / logout
    // -------------------------------------------------------------------------

    /**
     * Push the canonical team inventory and health modifier to a player who
     * just logged in.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) return;

        // Push inventory on the next tick (player's inventory may not be fully
        // initialised at the time this event fires).
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            inventorySyncService.pushInventoryToPlayer(player, team);
            inventorySyncService.pushEnderChestToPlayer(player, team);
            healthSyncService.applyHealthModifier(player, team);
        });
    }

    /**
     * Capture the player's inventory before they disconnect so the canonical
     * snapshot is up to date.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) return;
        inventorySyncService.captureInventoryFromPlayer(player, team);
        teamManager.saveInventories(team);
    }

    // -------------------------------------------------------------------------
    // Health changes
    // -------------------------------------------------------------------------

    /**
     * Propagate damage to all online teammates.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!config.isSyncHealth()) return;
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;

        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null || team.getMembers().size() <= 1) return;

        double newHealth = Math.max(0.0, player.getHealth() - event.getFinalDamage());
        healthSyncService.syncHealthToTeam(player, team, newHealth);
    }

    /**
     * Propagate healing to all online teammates.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityRegainHealth(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!config.isSyncHealth()) return;
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;

        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null || team.getMembers().size() <= 1) return;

        double maxHealth = player.getAttribute(
            org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();
        double newHealth = Math.min(maxHealth, player.getHealth() + event.getAmount());
        healthSyncService.syncHealthToTeam(player, team, newHealth);
    }

    // -------------------------------------------------------------------------
    // Food / saturation
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!config.isSyncHunger()) return;
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;

        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null || team.getMembers().size() <= 1) return;

        healthSyncService.syncFoodToTeam(player, team, event.getFoodLevel(), player.getSaturation());
    }

    // -------------------------------------------------------------------------
    // Respawn message
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) return;

        // Notify the player that inventory was cleared
        player.sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&',
            "&eYour shared inventory was cleared. Start fresh with your team!"));

        // Ensure health modifier is reapplied after respawn
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                healthSyncService.applyHealthModifier(player, team);
            }
        });
    }

    // -------------------------------------------------------------------------
    // Armor equip sync (via inventory change via InventoryListener — extra
    // coverage for armour stands / dispensers equipping armor indirectly)
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerItemHeld(PlayerItemHeldEvent event) {
        // Hotbar changes can affect effective item — schedule a sync.
        Player player = event.getPlayer();
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null || team.getMembers().size() <= 1) return;
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                inventorySyncService.syncFromPlayer(player, team);
            }
        });
    }
}
