package com.inventorysteal.listener;

import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.service.InventorySyncService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Detects all player-inventory mutations and triggers synchronisation to
 * teammates via {@link InventorySyncService}.
 *
 * <p>Events are handled at {@link EventPriority#MONITOR} so that other plugins
 * can cancel them first; we only sync when the event was not cancelled.
 *
 * <p>Re-entrant syncs (programmatic pushes to teammates) are guarded by the
 * syncing-lock in {@link SharedInventoryManager}.
 */
public class InventoryListener implements Listener {

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final InventorySyncService inventorySyncService;
    private final JavaPlugin plugin;

    public InventoryListener(TeamManager teamManager,
                             SharedInventoryManager sharedInvManager,
                             InventorySyncService inventorySyncService,
                             JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.inventorySyncService = inventorySyncService;
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Inventory click (most common mutation — hotbar, picking up, moving items)
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;

        Inventory clicked = event.getClickedInventory();
        Inventory top = event.getView().getTopInventory();

        // Handle team storage interactions
        if (clicked != null && sharedInvManager.isTeamStorage(clicked)) {
            // Allow the click; flush storage on next tick after Bukkit updates contents
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                Team team = teamManager.getTeamByMember(player.getUniqueId());
                if (team != null) {
                    // Sync storage contents back to team model
                    java.util.UUID teamId = sharedInvManager.getTeamForStorage(clicked);
                    if (teamId != null && teamId.equals(team.getId())) {
                        team.setTeamStorage(clicked.getContents().clone());
                        teamManager.saveInventories(team);
                    }
                }
            });
            return;
        }

        // For player inventory clicks, schedule sync on next tick so Bukkit
        // has applied the change before we read the inventory state.
        scheduleInventorySync(player);
    }

    // -------------------------------------------------------------------------
    // Drag event (distribute stack across slots)
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;

        scheduleInventorySync(player);
    }

    // -------------------------------------------------------------------------
    // Inventory close (covers shift-click to ender chest, storage, etc.)
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;

        Inventory closed = event.getInventory();

        // If closing the team storage GUI, flush and persist
        if (sharedInvManager.isTeamStorage(closed)) {
            Team team = teamManager.getTeamByMember(player.getUniqueId());
            if (team != null) {
                boolean flushed = sharedInvManager.onStorageClosed(player, team);
                if (flushed) {
                    teamManager.saveInventories(team);
                }
            }
            return;
        }

        // If the player was viewing their ender chest, sync it
        if (closed != null && closed.equals(player.getEnderChest())) {
            Team team = teamManager.getTeamByMember(player.getUniqueId());
            if (team != null && !sharedInvManager.isSyncing(player.getUniqueId())) {
                inventorySyncService.syncEnderChestFromPlayer(player, team);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Item drop
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;
        scheduleInventorySync(player);
    }

    // -------------------------------------------------------------------------
    // Item pickup
    // -------------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerPickupItem(PlayerPickupItemEvent event) {
        Player player = event.getPlayer();
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;
        scheduleInventorySync(player);
    }

    // -------------------------------------------------------------------------
    // Swap hands (F key)
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (sharedInvManager.isSyncing(player.getUniqueId())) return;
        scheduleInventorySync(player);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Schedule an inventory sync on the next server tick.
     *
     * <p>We defer by one tick so that Bukkit has fully committed the inventory
     * change before we read it and propagate to teammates.
     *
     * @param player player whose inventory changed
     */
    private void scheduleInventorySync(Player player) {
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) return;
        if (team.getMembers().size() <= 1) return; // solo — no-op

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                inventorySyncService.syncFromPlayer(player, team);
            }
        });
    }
}
