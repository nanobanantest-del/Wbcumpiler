package com.inventorysteal.listener;

import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.service.DeathService;
import com.inventorysteal.service.InventorySyncService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Intercepts player-death events and triggers the team-death cascade.
 *
 * <p>When any team member dies:
 * <ol>
 *   <li>Item drops from the death event are suppressed (we handle drops ourselves).</li>
 *   <li>{@link DeathService#processTeamDeath} is called to kill all teammates.</li>
 * </ol>
 */
public class DeathListener implements Listener {

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final DeathService deathService;
    private final InventorySyncService inventorySyncService;
    private final JavaPlugin plugin;

    public DeathListener(TeamManager teamManager,
                         SharedInventoryManager sharedInvManager,
                         DeathService deathService,
                         InventorySyncService inventorySyncService,
                         JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.deathService = deathService;
        this.inventorySyncService = inventorySyncService;
        this.plugin = plugin;
    }

    /**
     * Handle a player dying.
     *
     * <p>Event priority {@link EventPriority#HIGH} so we intercept before most
     * other plugins process the death, but after plugins that might cancel it
     * (e.g. resurrection items).
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) return;
        if (team.getMembers().size() <= 1) return; // solo team — no cascade needed

        // Skip if this death was already triggered by the cascade itself
        if (deathService.isProcessingDeath(player.getUniqueId())) {
            // Suppress vanilla drops — we drop manually in DeathService
            event.getDrops().clear();
            event.setDroppedExp(0);
            return;
        }

        // Suppress vanilla drops for the triggering player —
        // DeathService will drop items manually so we can also clear all teammates.
        event.getDrops().clear();
        event.setDroppedExp(0);

        // Trigger the team-death cascade on the main thread.
        // We are already on the main thread here (event handler), but wrap in
        // runTask to ensure all pre-death event processing is complete first.
        plugin.getServer().getScheduler().runTask(plugin, () ->
            deathService.processTeamDeath(player, team)
        );
    }
}
