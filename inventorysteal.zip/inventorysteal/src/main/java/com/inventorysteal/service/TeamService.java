package com.inventorysteal.service;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * High-level team business logic.
 *
 * <p>All methods are intended to be called from the main server thread.
 * Return values indicate success/failure; message delivery to players is
 * handled here so commands stay thin.
 */
public class TeamService {

    /** Result codes for team operations. */
    public enum Result {
        SUCCESS,
        ALREADY_IN_TEAM,
        NOT_IN_TEAM,
        NOT_LEADER,
        TEAM_FULL,
        TEAM_NOT_FOUND,
        NAME_TAKEN,
        NAME_INVALID,
        PLAYER_NOT_FOUND,
        ALREADY_INVITED,
        INVITE_NOT_FOUND,
        KICK_SELF,
        KICK_NOT_MEMBER,
        ON_COOLDOWN,
        MAX_STORAGE_REACHED,
        NO_UPGRADE_ITEM,
        ALREADY_LEADER
    }

    private final TeamManager teamManager;
    private final InventorySyncService inventorySyncService;
    private final HealthSyncService healthSyncService;
    private final ConfigManager config;
    private final MessagesManager messages;
    private final JavaPlugin plugin;

    /** Cooldown tracking: player UUID → action name → System.currentTimeMillis() of last use. */
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();

    public TeamService(TeamManager teamManager,
                       InventorySyncService inventorySyncService,
                       HealthSyncService healthSyncService,
                       ConfigManager config,
                       MessagesManager messages,
                       JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.inventorySyncService = inventorySyncService;
        this.healthSyncService = healthSyncService;
        this.config = config;
        this.messages = messages;
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // /team create <name>
    // -------------------------------------------------------------------------

    /**
     * Create a new team.
     *
     * @param leader player creating the team
     * @param name   desired team name
     * @return result code
     */
    public Result createTeam(Player leader, String name) {
        if (teamManager.isInTeam(leader.getUniqueId())) return Result.ALREADY_IN_TEAM;
        if (!isValidName(name)) return Result.NAME_INVALID;
        if (teamManager.teamNameExists(name)) return Result.NAME_TAKEN;
        if (isOnCooldown(leader.getUniqueId(), "create", config.getCooldownCreate())) return Result.ON_COOLDOWN;

        Team team = teamManager.createTeam(name, leader.getUniqueId());

        // Apply any existing health modifier (none yet for a new team)
        healthSyncService.applyHealthModifier(leader, team);

        setCooldown(leader.getUniqueId(), "create");
        leader.sendMessage(messages.format("team.created", Map.of("team", name)));
        return Result.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // /team invite <player>
    // -------------------------------------------------------------------------

    /**
     * Invite a player to the leader's team.
     *
     * @param sender  player sending the invite (must be a team member)
     * @param target  player to invite
     * @return result code
     */
    public Result invitePlayer(Player sender, Player target) {
        Team team = teamManager.getTeamByMember(sender.getUniqueId());
        if (team == null) return Result.NOT_IN_TEAM;
        if (!team.isLeader(sender.getUniqueId())) return Result.NOT_LEADER;
        if (teamManager.isInTeam(target.getUniqueId())) return Result.ALREADY_IN_TEAM;
        if (config.getMaxTeamSize() > 0 && team.getMemberCount() >= config.getMaxTeamSize())
            return Result.TEAM_FULL;
        if (team.hasPendingInvite(target.getUniqueId())) return Result.ALREADY_INVITED;

        PendingInvite invite = new PendingInvite(
            team.getId(), target.getUniqueId(), sender.getUniqueId(), config.getInviteTimeout());
        team.addPendingInvite(invite);
        teamManager.getTeamByMember(sender.getUniqueId()); // ensure cached

        // Save invite to DB
        plugin.getServer().getScheduler().runTask(plugin, () ->
            teamManager.saveTeam(team) // also saves invite via repo
        );

        // Persist invite (done inline since we're on the main thread)
        saveInvite(invite);

        // Notify target
        target.sendMessage(messages.format("team.invite-received", Map.of(
            "team", team.getName(),
            "player", sender.getName())));

        // Notify sender
        sender.sendMessage(messages.format("team.invite-sent", Map.of(
            "player", target.getName(),
            "timeout", String.valueOf(config.getInviteTimeout()))));

        // Schedule expiry
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (team.hasPendingInvite(target.getUniqueId())) {
                PendingInvite existing = team.getPendingInvites().get(target.getUniqueId());
                if (existing != null && existing.isExpired()) {
                    team.removePendingInvite(target.getUniqueId());
                    removeInvite(team.getId(), target.getUniqueId());
                    if (target.isOnline()) {
                        target.sendMessage(messages.format("team.invite-expired",
                            Map.of("team", team.getName())));
                    }
                    if (sender.isOnline()) {
                        sender.sendMessage(messages.format("team.invite-expired-sender",
                            Map.of("player", target.getName(), "team", team.getName())));
                    }
                }
            }
        }, config.getInviteTimeout() * 20L);

        return Result.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // /team accept <team>
    // -------------------------------------------------------------------------

    /**
     * Accept a pending invite.
     *
     * @param player   player accepting
     * @param teamName team they were invited to
     * @return result code
     */
    public Result acceptInvite(Player player, String teamName) {
        if (teamManager.isInTeam(player.getUniqueId())) return Result.ALREADY_IN_TEAM;

        Team team = teamManager.getTeamByName(teamName);
        if (team == null) return Result.TEAM_NOT_FOUND;

        PendingInvite invite = team.getPendingInvites().get(player.getUniqueId());
        if (invite == null || invite.isExpired()) return Result.INVITE_NOT_FOUND;

        if (config.getMaxTeamSize() > 0 && team.getMemberCount() >= config.getMaxTeamSize())
            return Result.TEAM_FULL;

        // Accept
        team.removePendingInvite(player.getUniqueId());
        removeInvite(team.getId(), player.getUniqueId());
        teamManager.addMember(team, player.getUniqueId());

        // Sync inventories to the new member
        inventorySyncService.pushInventoryToPlayer(player, team);
        healthSyncService.applyHealthModifier(player, team);

        // Broadcast
        broadcastToTeam(team, messages.format("team.joined-broadcast",
            Map.of("player", player.getName(), "team", team.getName())));
        player.sendMessage(messages.format("team.joined", Map.of("team", team.getName())));

        return Result.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // /team leave
    // -------------------------------------------------------------------------

    /**
     * Leave a team.
     *
     * @param player player leaving
     * @return result code
     */
    public Result leaveTeam(Player player) {
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) return Result.NOT_IN_TEAM;
        if (team.isLeader(player.getUniqueId())) return Result.NOT_LEADER; // leader must disband
        if (isOnCooldown(player.getUniqueId(), "leave", config.getCooldownLeave())) return Result.ON_COOLDOWN;

        // Save current inventory state before leaving
        inventorySyncService.captureInventoryFromPlayer(player, team);
        teamManager.saveInventories(team);

        teamManager.removeMember(team, player.getUniqueId());
        healthSyncService.removeHealthModifier(player);

        setCooldown(player.getUniqueId(), "leave");
        broadcastToTeam(team, messages.format("team.left-broadcast",
            Map.of("player", player.getName(), "team", team.getName())));
        player.sendMessage(messages.format("team.left", Map.of("team", team.getName())));

        return Result.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // /team kick <player>
    // -------------------------------------------------------------------------

    /**
     * Kick a member.
     *
     * @param leader player issuing the kick (must be team leader)
     * @param target player to kick
     * @return result code
     */
    public Result kickMember(Player leader, Player target) {
        Team team = teamManager.getTeamByMember(leader.getUniqueId());
        if (team == null) return Result.NOT_IN_TEAM;
        if (!team.isLeader(leader.getUniqueId())) return Result.NOT_LEADER;
        if (leader.getUniqueId().equals(target.getUniqueId())) return Result.KICK_SELF;
        if (!team.isMember(target.getUniqueId())) return Result.KICK_NOT_MEMBER;

        teamManager.removeMember(team, target.getUniqueId());
        healthSyncService.removeHealthModifier(target);

        broadcastToTeam(team, messages.format("team.kicked-broadcast",
            Map.of("player", target.getName(), "team", team.getName(), "kicker", leader.getName())));
        target.sendMessage(messages.format("team.kicked",
            Map.of("team", team.getName(), "kicker", leader.getName())));

        return Result.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // /team disband
    // -------------------------------------------------------------------------

    /**
     * Disband the leader's team.
     *
     * @param leader player disbanding (must be team leader)
     * @return result code
     */
    public Result disbandTeam(Player leader) {
        Team team = teamManager.getTeamByMember(leader.getUniqueId());
        if (team == null) return Result.NOT_IN_TEAM;
        if (!team.isLeader(leader.getUniqueId())) return Result.NOT_LEADER;
        if (isOnCooldown(leader.getUniqueId(), "disband", config.getCooldownDisband())) return Result.ON_COOLDOWN;

        // Remove health modifiers from all online members before disbanding
        for (UUID memberUUID : new ArrayList<>(team.getMembers())) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null) {
                healthSyncService.removeHealthModifier(member);
            }
        }

        broadcastToTeam(team, messages.format("team.disband-broadcast",
            Map.of("team", team.getName(), "player", leader.getName())));
        teamManager.disbandTeam(team);
        setCooldown(leader.getUniqueId(), "disband");
        return Result.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // Cooldown helpers
    // -------------------------------------------------------------------------

    private boolean isOnCooldown(UUID playerUUID, String action, int cooldownSeconds) {
        if (cooldownSeconds <= 0) return false;
        Map<String, Long> playerCooldowns = cooldowns.getOrDefault(playerUUID, Collections.emptyMap());
        Long lastUse = playerCooldowns.get(action);
        if (lastUse == null) return false;
        return System.currentTimeMillis() - lastUse < cooldownSeconds * 1000L;
    }

    /** Remaining seconds on a cooldown, or 0 if expired. */
    public long remainingCooldown(UUID playerUUID, String action, int cooldownSeconds) {
        Map<String, Long> playerCooldowns = cooldowns.getOrDefault(playerUUID, Collections.emptyMap());
        Long lastUse = playerCooldowns.get(action);
        if (lastUse == null) return 0;
        long elapsed = (System.currentTimeMillis() - lastUse) / 1000;
        return Math.max(0, cooldownSeconds - elapsed);
    }

    private void setCooldown(UUID playerUUID, String action) {
        cooldowns.computeIfAbsent(playerUUID, k -> new ConcurrentHashMap<>())
                 .put(action, System.currentTimeMillis());
    }

    // -------------------------------------------------------------------------
    // Validation helpers
    // -------------------------------------------------------------------------

    /**
     * Team names must be 3-16 characters, letters/numbers/underscores only.
     */
    public static boolean isValidName(String name) {
        return name != null && name.matches("^[a-zA-Z0-9_]{3,16}$");
    }

    // -------------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------------

    /**
     * Broadcast a message to all online members of a team.
     *
     * @param team    target team
     * @param message formatted message to send
     */
    public void broadcastToTeam(Team team, String message) {
        for (UUID memberUUID : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                member.sendMessage(message);
            }
        }
    }

    private void saveInvite(PendingInvite invite) {
        teamManager.saveInvite(invite);
    }

    private void removeInvite(UUID teamId, UUID playerUUID) {
        teamManager.removeInvite(teamId, playerUUID);
    }
}
