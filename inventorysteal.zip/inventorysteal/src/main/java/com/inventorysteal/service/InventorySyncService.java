package com.inventorysteal.service;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.util.SerializationUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Handles all player-inventory synchronisation between team members.
 *
 * <p>Design invariants:
 * <ul>
 *   <li>Only called from the <em>main server thread</em>.</li>
 *   <li>Uses the {@link SharedInventoryManager} syncing-lock to prevent
 *       re-entrant updates when programmatically setting another player's
 *       inventory, which would otherwise trigger a second sync event.</li>
 *   <li>The canonical inventory snapshot stored in the {@link Team} is always
 *       updated <em>before</em> pushing to teammates.</li>
 * </ul>
 */
public class InventorySyncService {

    private static final Logger LOGGER = Logger.getLogger(InventorySyncService.class.getName());

    /** Main inventory slot count (0-35 = main + hotbar). */
    public static final int MAIN_SLOTS = 36;
    /** Total slots in a player's full inventory: 36 main + 4 armor + 1 offhand. */
    public static final int TOTAL_PLAYER_SLOTS = 41;

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final ConfigManager config;
    private final JavaPlugin plugin;

    public InventorySyncService(TeamManager teamManager,
                                SharedInventoryManager sharedInvManager,
                                ConfigManager config,
                                JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.config = config;
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Capture (player → canonical)
    // -------------------------------------------------------------------------

    /**
     * Read the current player inventory and save it as the canonical team
     * inventory, then push the update to all other online teammates.
     *
     * <p>This is the primary entry point called by inventory event listeners.
     *
     * @param source the player whose inventory changed
     * @param team   the team this player belongs to
     */
    public void syncFromPlayer(Player source, Team team) {
        if (sharedInvManager.isSyncing(source.getUniqueId())) {
            // This update was triggered by us — skip to prevent recursion.
            return;
        }

        // Capture source's inventory into the canonical snapshot
        captureInventoryFromPlayer(source, team);

        // Save to DB (async-friendly since SQLite/MySQL calls are lightweight)
        teamManager.saveInventories(team);

        // Push to all other online teammates
        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate != null && teammate.isOnline()) {
                pushInventoryToPlayer(teammate, team);
            }
        }
    }

    /**
     * Sync the ender chest of the source player to all teammates.
     *
     * @param source player whose ender chest changed
     * @param team   the team
     */
    public void syncEnderChestFromPlayer(Player source, Team team) {
        if (!config.isSyncEnderChest()) return;
        if (sharedInvManager.isSyncing(source.getUniqueId())) return;

        // Capture
        ItemStack[] enderChest = source.getEnderChest().getContents();
        team.setSharedEnderChest(SerializationUtil.cloneArray(enderChest));
        teamManager.saveInventories(team);

        // Push to teammates
        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate != null && teammate.isOnline()) {
                pushEnderChestToPlayer(teammate, team);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Push (canonical → player)
    // -------------------------------------------------------------------------

    /**
     * Push the canonical team inventory to a single player.
     *
     * <p>Sets the syncing lock before modifying the player's inventory and
     * clears it immediately after to prevent re-entrant event processing.
     *
     * @param target player to receive the update
     * @param team   source team
     */
    public void pushInventoryToPlayer(Player target, Team team) {
        ItemStack[] canonical = team.getCanonicalInventory();
        if (canonical == null) return;

        sharedInvManager.beginSync(target.getUniqueId());
        try {
            PlayerInventory inv = target.getInventory();

            if (config.isSyncMain()) {
                for (int i = 0; i < MAIN_SLOTS && i < canonical.length; i++) {
                    inv.setItem(i, canonical[i] != null ? canonical[i].clone() : null);
                }
            }

            if (config.isSyncArmor() && canonical.length >= 40) {
                // Armor slots 36–39 (helmet=39, chest=38, legs=37, boots=36)
                inv.setHelmet(canonical[39] != null ? canonical[39].clone() : null);
                inv.setChestplate(canonical[38] != null ? canonical[38].clone() : null);
                inv.setLeggings(canonical[37] != null ? canonical[37].clone() : null);
                inv.setBoots(canonical[36] != null ? canonical[36].clone() : null);
            }

            if (config.isSyncOffhand() && canonical.length == 41) {
                inv.setItemInOffHand(canonical[40] != null ? canonical[40].clone() : null);
            }

            target.updateInventory();
        } finally {
            sharedInvManager.endSync(target.getUniqueId());
        }
    }

    /**
     * Push the shared ender-chest contents to a single player.
     *
     * @param target player to receive the update
     * @param team   source team
     */
    public void pushEnderChestToPlayer(Player target, Team team) {
        if (!config.isSyncEnderChest()) return;
        ItemStack[] shared = team.getSharedEnderChest();
        if (shared == null) return;

        sharedInvManager.beginSync(target.getUniqueId());
        try {
            Inventory ec = target.getEnderChest();
            for (int i = 0; i < Math.min(shared.length, ec.getSize()); i++) {
                ec.setItem(i, shared[i] != null ? shared[i].clone() : null);
            }
        } finally {
            sharedInvManager.endSync(target.getUniqueId());
        }
    }

    // -------------------------------------------------------------------------
    // Capture helpers
    // -------------------------------------------------------------------------

    /**
     * Read the player's current inventory into the team's canonical snapshot.
     * Does NOT push to teammates; call {@link #syncFromPlayer} for the full flow.
     *
     * @param player source player
     * @param team   target team
     */
    public void captureInventoryFromPlayer(Player player, Team team) {
        PlayerInventory inv = player.getInventory();
        ItemStack[] snapshot = new ItemStack[TOTAL_PLAYER_SLOTS];

        // Slots 0–35: main inventory + hotbar
        for (int i = 0; i < MAIN_SLOTS; i++) {
            ItemStack item = inv.getItem(i);
            snapshot[i] = item != null ? item.clone() : null;
        }

        // Slots 36–39: armor (boots, leggings, chestplate, helmet)
        snapshot[36] = inv.getBoots() != null ? inv.getBoots().clone() : null;
        snapshot[37] = inv.getLeggings() != null ? inv.getLeggings().clone() : null;
        snapshot[38] = inv.getChestplate() != null ? inv.getChestplate().clone() : null;
        snapshot[39] = inv.getHelmet() != null ? inv.getHelmet().clone() : null;

        // Slot 40: offhand
        snapshot[40] = inv.getItemInOffHand() != null ? inv.getItemInOffHand().clone() : null;

        team.setCanonicalInventory(snapshot);
    }

    /**
     * Clear a player's inventory completely (used during team death).
     *
     * @param player player to clear
     */
    public void clearPlayerInventory(Player player) {
        sharedInvManager.beginSync(player.getUniqueId());
        try {
            PlayerInventory inv = player.getInventory();
            inv.clear();
            inv.setHelmet(null);
            inv.setChestplate(null);
            inv.setLeggings(null);
            inv.setBoots(null);
            inv.setItemInOffHand(null);
            player.getEnderChest().clear();
            player.updateInventory();
        } finally {
            sharedInvManager.endSync(player.getUniqueId());
        }
    }
}
