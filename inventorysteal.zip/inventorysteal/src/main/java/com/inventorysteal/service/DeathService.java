package com.inventorysteal.service;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.util.SerializationUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.logging.Logger;

/**
 * Handles the team-death event: when any team member dies, all teammates
 * are also killed, their inventories are dropped, and the shared state
 * is cleared.
 *
 * <p>All methods must be called from the main server thread.
 */
public class DeathService {

    private static final Logger LOGGER = Logger.getLogger(DeathService.class.getName());

    /** Players whose death is currently being processed to prevent recursion. */
    private final Set<UUID> processingDeath = new HashSet<>();

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final ConfigManager config;
    private final MessagesManager messages;
    private final JavaPlugin plugin;

    public DeathService(TeamManager teamManager,
                        SharedInventoryManager sharedInvManager,
                        ConfigManager config,
                        MessagesManager messages,
                        JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.config = config;
        this.messages = messages;
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Primary entry point
    // -------------------------------------------------------------------------

    /**
     * Process a team-death triggered by {@code trigger}.
     *
     * <p>The following steps are executed in order:
     * <ol>
     *   <li>Mark all members as "processing death" to prevent re-entrancy.</li>
     *   <li>Optionally drop each online member's inventory at their location.</li>
     *   <li>Kill all online teammates (except {@code trigger}, who is already
     *       dead / dying).</li>
     *   <li>Optionally clear the shared inventory and ender chest.</li>
     *   <li>Persist the cleared state.</li>
     *   <li>Notify the team.</li>
     * </ol>
     *
     * @param trigger the player whose death caused the cascade
     * @param team    the team
     */
    public void processTeamDeath(Player trigger, Team team) {
        if (!config.isTeamDeath()) return;
        if (processingDeath.contains(trigger.getUniqueId())) return;

        LOGGER.fine("Team death triggered by " + trigger.getName() + " in team " + team.getName());

        // Mark all members to prevent recursive calls
        List<UUID> members = new ArrayList<>(team.getMembers());
        members.forEach(processingDeath::add);

        // Drop inventories on the ground for each online member
        if (config.isDropInventories()) {
            for (UUID memberUUID : members) {
                Player member = Bukkit.getPlayer(memberUUID);
                if (member != null && member.isOnline() && !memberUUID.equals(trigger.getUniqueId())) {
                    dropInventory(member);
                }
                // trigger's inventory is dropped by the vanilla death event
            }
        }

        // Kill all online teammates (other than the trigger who is already dead)
        for (UUID memberUUID : members) {
            if (memberUUID.equals(trigger.getUniqueId())) continue;
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline() && member.isValid()) {
                sharedInvManager.beginSync(member.getUniqueId());
                try {
                    member.setHealth(0.0);
                } finally {
                    sharedInvManager.endSync(member.getUniqueId());
                }
            }
        }

        // Clear shared state
        if (config.isClearSharedInventory()) {
            clearSharedState(team);
        }

        // Force-close any open team-storage GUIs
        sharedInvManager.forceCloseStorage(team);

        // Persist
        teamManager.saveInventories(team);

        // Notify all members
        String deathMsg = messages.format("death.team-death-message",
            Map.of("player", trigger.getName()));
        for (UUID memberUUID : members) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                member.sendMessage(deathMsg);
                playSoundSafe(member, config.getSoundTeamDeath());
            }
        }

        // Schedule unlock on next tick (after all death events have processed)
        Bukkit.getScheduler().runTask(plugin, () -> members.forEach(processingDeath::remove));
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * @param playerUUID player UUID
     * @return {@code true} if this player's death is currently being processed
     */
    public boolean isProcessingDeath(UUID playerUUID) {
        return processingDeath.contains(playerUUID);
    }

    /**
     * Drop all items from a player's inventory at their current location.
     *
     * @param player player whose items should be dropped
     */
    private void dropInventory(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (ItemStack item : contents) {
            if (item != null) {
                player.getWorld().dropItemNaturally(player.getLocation(), item.clone());
            }
        }

        ItemStack[] armor = player.getInventory().getArmorContents();
        for (ItemStack item : armor) {
            if (item != null) {
                player.getWorld().dropItemNaturally(player.getLocation(), item.clone());
            }
        }

        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand != null && offhand.getType() != org.bukkit.Material.AIR) {
            player.getWorld().dropItemNaturally(player.getLocation(), offhand.clone());
        }

        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[4]);
        player.getInventory().setItemInOffHand(null);
        player.updateInventory();
    }

    /**
     * Clear all shared state (canonical inventory, ender chest, team storage).
     *
     * @param team team to clear
     */
    private void clearSharedState(Team team) {
        team.setCanonicalInventory(SerializationUtil.emptyArray(41));
        team.setSharedEnderChest(SerializationUtil.emptyArray(27));
        team.setTeamStorage(SerializationUtil.emptyArray(team.getStorageSlots()));

        // Clear all online members' inventories too
        for (UUID memberUUID : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                sharedInvManager.beginSync(member.getUniqueId());
                try {
                    member.getInventory().clear();
                    member.getInventory().setArmorContents(new ItemStack[4]);
                    member.getInventory().setItemInOffHand(null);
                    member.getEnderChest().clear();
                    member.updateInventory();
                } finally {
                    sharedInvManager.endSync(member.getUniqueId());
                }
            }
        }
    }

    /**
     * Play a sound for a player, catching any invalid sound-name errors.
     *
     * @param player    target
     * @param soundName Bukkit sound name string from config
     */
    private void playSoundSafe(Player player, String soundName) {
        if (!config.isSoundsEnabled()) return;
        try {
            Sound sound = Sound.valueOf(soundName);
            player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
        } catch (IllegalArgumentException e) {
            LOGGER.warning("Invalid sound name in config: " + soundName);
        }
    }
}
