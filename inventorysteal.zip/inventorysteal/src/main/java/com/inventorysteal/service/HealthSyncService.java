package com.inventorysteal.service;

import com.inventorysteal.config.ConfigManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * Synchronises health, hunger, saturation, air and fire-ticks between
 * team members, and manages the per-team max-health attribute modifier.
 *
 * <p>All methods must be called from the main server thread.
 */
public class HealthSyncService {

    private static final Logger LOGGER = Logger.getLogger(HealthSyncService.class.getName());

    /** Name prefix for the attribute modifier stored on each player. */
    private static final String MODIFIER_NAME = "inventorysteal.maxhealth";

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final ConfigManager config;
    private final JavaPlugin plugin;

    public HealthSyncService(TeamManager teamManager,
                             SharedInventoryManager sharedInvManager,
                             ConfigManager config,
                             JavaPlugin plugin) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.config = config;
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Health sync
    // -------------------------------------------------------------------------

    /**
     * Propagate health changes from the source player to all online teammates.
     *
     * @param source  player whose health changed
     * @param team    the team
     * @param newHealth the exact health value to apply to teammates
     */
    public void syncHealthToTeam(Player source, Team team, double newHealth) {
        if (!config.isSyncHealth()) return;

        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;

            double maxHealth = getMaxHealth(teammate);
            double clamped = Math.max(0.0, Math.min(newHealth, maxHealth));

            sharedInvManager.beginSync(teammate.getUniqueId());
            try {
                teammate.setHealth(clamped);
            } finally {
                sharedInvManager.endSync(teammate.getUniqueId());
            }
        }
    }

    /**
     * Propagate food and saturation from the source player.
     *
     * @param source      player whose food/saturation changed
     * @param team        the team
     * @param foodLevel   new food level (0-20)
     * @param saturation  new saturation
     */
    public void syncFoodToTeam(Player source, Team team, int foodLevel, float saturation) {
        if (!config.isSyncHunger()) return;

        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;

            sharedInvManager.beginSync(teammate.getUniqueId());
            try {
                teammate.setFoodLevel(foodLevel);
                if (config.isSyncSaturation()) teammate.setSaturation(saturation);
            } finally {
                sharedInvManager.endSync(teammate.getUniqueId());
            }
        }
    }

    /**
     * Sync remaining air to all teammates.
     *
     * @param source      player whose air changed
     * @param team        the team
     * @param remainingAir new air value
     */
    public void syncAirToTeam(Player source, Team team, int remainingAir) {
        if (!config.isSyncAir()) return;

        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;
            teammate.setRemainingAir(remainingAir);
        }
    }

    /**
     * Sync fire ticks to all teammates.
     *
     * @param source    player on fire
     * @param team      the team
     * @param fireTicks new fire tick count
     */
    public void syncFireTicksToTeam(Player source, Team team, int fireTicks) {
        if (!config.isSyncFireTicks()) return;

        for (UUID memberUUID : team.getMembers()) {
            if (memberUUID.equals(source.getUniqueId())) continue;
            Player teammate = Bukkit.getPlayer(memberUUID);
            if (teammate == null || !teammate.isOnline()) continue;
            teammate.setFireTicks(fireTicks);
        }
    }

    // -------------------------------------------------------------------------
    // Max-health attribute modifier
    // -------------------------------------------------------------------------

    /**
     * Apply (or update) the team's max-health modifier on a single player.
     * Existing modifiers with the same UUID are removed first to avoid stacking.
     *
     * @param player player to modify
     * @param team   the player's team
     */
    @SuppressWarnings("deprecation")
    public void applyHealthModifier(Player player, Team team) {
        double bonus = team.getMaxHealthBonus();
        AttributeInstance attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr == null) return;

        UUID modifierUUID = getModifierUUID(team);

        // Remove any existing modifier for this team
        attr.getModifiers().stream()
            .filter(m -> m.getUniqueId().equals(modifierUUID))
            .findFirst()
            .ifPresent(attr::removeModifier);

        if (bonus > 0) {
            AttributeModifier modifier = new AttributeModifier(
                modifierUUID,
                MODIFIER_NAME,
                bonus,
                AttributeModifier.Operation.ADD_NUMBER
            );
            attr.addModifier(modifier);

            // Ensure health does not exceed new max
            double maxHealth = attr.getValue();
            if (player.getHealth() > maxHealth) {
                player.setHealth(maxHealth);
            }
        }
    }

    /**
     * Remove the team health modifier from a player (used when they leave a team).
     *
     * @param player player to clean up
     */
    @SuppressWarnings("deprecation")
    public void removeHealthModifier(Player player) {
        AttributeInstance attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr == null) return;

        // Remove any modifier whose name matches ours
        attr.getModifiers().stream()
            .filter(m -> MODIFIER_NAME.equals(m.getName()))
            .toList() // collect first to avoid ConcurrentModificationException
            .forEach(attr::removeModifier);

        // Clamp health to new (lower) max
        double maxHealth = attr.getValue();
        if (player.getHealth() > maxHealth) {
            player.setHealth(maxHealth);
        }
    }

    /**
     * Add one heart-unit of max health to the entire team and persist it.
     *
     * @param team team to upgrade
     * @return {@code false} if the max health limit has been reached
     */
    public boolean addHeart(Team team) {
        double hpToAdd = config.getHpPerHeart();
        double limit = config.getMaxHealthBonus();

        if (limit > 0 && team.getMaxHealthBonus() + hpToAdd > limit) {
            return false;
        }

        team.setMaxHealthBonus(team.getMaxHealthBonus() + hpToAdd);
        teamManager.saveHealthBonus(team, team.getMaxHealthBonus());

        // Apply to all online members
        for (UUID memberUUID : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                applyHealthModifier(member, team);
            }
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Derive a stable {@link UUID} for the attribute modifier based on the team ID.
     */
    private UUID getModifierUUID(Team team) {
        return UUID.nameUUIDFromBytes(("inventorysteal.health." + team.getId()).getBytes());
    }

    /**
     * Get the effective max health of a player.
     */
    private double getMaxHealth(Player player) {
        AttributeInstance attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        return attr != null ? attr.getValue() : 20.0;
    }
}
