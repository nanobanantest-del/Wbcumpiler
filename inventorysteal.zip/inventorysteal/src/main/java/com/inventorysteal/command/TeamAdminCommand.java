package com.inventorysteal.command;

import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.Team;
import com.inventorysteal.service.HealthSyncService;
import com.inventorysteal.service.InventorySyncService;
import com.inventorysteal.util.SerializationUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Handles all {@code /teamadmin} subcommands.
 *
 * <pre>
 * /teamadmin delete         &lt;team&gt;
 * /teamadmin resetinventory &lt;team&gt;
 * /teamadmin resethearts    &lt;team&gt;
 * /teamadmin resetupgrades  &lt;team&gt;
 * /teamadmin resetall       &lt;team&gt;
 * /teamadmin list
 * </pre>
 */
public class TeamAdminCommand implements CommandExecutor, TabCompleter {

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final HealthSyncService healthSyncService;
    private final InventorySyncService inventorySyncService;
    private final MessagesManager messages;

    public TeamAdminCommand(TeamManager teamManager,
                            SharedInventoryManager sharedInvManager,
                            HealthSyncService healthSyncService,
                            InventorySyncService inventorySyncService,
                            MessagesManager messages) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.healthSyncService = healthSyncService;
        this.inventorySyncService = inventorySyncService;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (!sender.hasPermission("inventorysteal.teamadmin")) {
            sender.sendMessage(messages.getRaw("general.no-permission"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "delete"         -> handleDelete(sender, args);
            case "resetinventory" -> handleResetInventory(sender, args);
            case "resethearts"    -> handleResetHearts(sender, args);
            case "resetupgrades"  -> handleResetUpgrades(sender, args);
            case "resetall"       -> handleResetAll(sender, args);
            case "list"           -> handleList(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Subcommand implementations
    // -------------------------------------------------------------------------

    private void handleDelete(CommandSender sender, String[] args) {
        Team team = requireTeam(sender, args);
        if (team == null) return;

        // Remove health modifiers from online members
        for (UUID memberUUID : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null) healthSyncService.removeHealthModifier(member);
        }
        sharedInvManager.forceCloseStorage(team);
        teamManager.disbandTeam(team);
        sender.sendMessage(messages.format("admin.team-deleted",
            Map.of("team", team.getName())));
    }

    private void handleResetInventory(CommandSender sender, String[] args) {
        Team team = requireTeam(sender, args);
        if (team == null) return;

        // Clear all inventory arrays
        team.setCanonicalInventory(SerializationUtil.emptyArray(41));
        team.setSharedEnderChest(SerializationUtil.emptyArray(27));
        team.setTeamStorage(SerializationUtil.emptyArray(team.getStorageSlots()));

        // Push empty inventory to all online members
        for (UUID memberUUID : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                inventorySyncService.pushInventoryToPlayer(member, team);
                inventorySyncService.pushEnderChestToPlayer(member, team);
            }
        }
        teamManager.saveInventories(team);
        sender.sendMessage(messages.format("admin.inventory-reset",
            Map.of("team", team.getName())));
    }

    private void handleResetHearts(CommandSender sender, String[] args) {
        Team team = requireTeam(sender, args);
        if (team == null) return;

        team.setMaxHealthBonus(0.0);
        teamManager.saveHealthBonus(team, 0.0);

        // Remove health modifiers from online members
        for (UUID memberUUID : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberUUID);
            if (member != null && member.isOnline()) {
                healthSyncService.removeHealthModifier(member);
            }
        }
        sender.sendMessage(messages.format("admin.hearts-reset",
            Map.of("team", team.getName())));
    }

    private void handleResetUpgrades(CommandSender sender, String[] args) {
        Team team = requireTeam(sender, args);
        if (team == null) return;

        // Reset storage to default size (27 slots) and clear all items
        int defaultSlots = 27;
        team.resetStorage(defaultSlots);
        teamManager.saveStorageUpgrade(team, defaultSlots);
        teamManager.saveInventories(team);
        sender.sendMessage(messages.format("admin.upgrades-reset",
            Map.of("team", team.getName())));
    }

    private void handleResetAll(CommandSender sender, String[] args) {
        Team team = requireTeam(sender, args);
        if (team == null) return;

        handleResetInventory(sender, args);
        handleResetHearts(sender, args);
        handleResetUpgrades(sender, args);
        sender.sendMessage(messages.format("admin.all-reset",
            Map.of("team", team.getName())));
    }

    private void handleList(CommandSender sender) {
        Collection<Team> teams = teamManager.getAllTeams();
        sender.sendMessage("§8§m---§r §6All Teams §8§m---");
        if (teams.isEmpty()) {
            sender.sendMessage("§7No teams exist.");
        } else {
            for (Team team : teams) {
                sender.sendMessage("§e" + team.getName()
                    + " §8(" + team.getMemberCount() + " members)"
                    + " §7hearts: " + (int)(team.getMaxHealthBonus()/2)
                    + " §7storage: " + team.getStorageSlots());
            }
        }
    }

    // -------------------------------------------------------------------------
    // Tab completion
    // -------------------------------------------------------------------------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (!sender.hasPermission("inventorysteal.teamadmin")) return Collections.emptyList();

        if (args.length == 1) {
            return filterPrefix(args[0],
                "delete", "resetinventory", "resethearts", "resetupgrades", "resetall", "list");
        }
        if (args.length == 2) {
            return teamManager.getAllTeams().stream()
                .map(Team::getName)
                .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Team requireTeam(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cUsage: §e/" + "teamadmin " + args[0] + " <team>");
            return null;
        }
        Team team = teamManager.getTeamByName(args[1]);
        if (team == null) {
            sender.sendMessage(messages.format("team.team-not-found",
                Map.of("team", args[1])));
        }
        return team;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§8§m------§r §6/teamadmin §8§m------");
        sender.sendMessage("§e/teamadmin delete         §7<team> - Delete a team");
        sender.sendMessage("§e/teamadmin resetinventory §7<team> - Reset inventories");
        sender.sendMessage("§e/teamadmin resethearts    §7<team> - Reset heart upgrades");
        sender.sendMessage("§e/teamadmin resetupgrades  §7<team> - Reset storage upgrades");
        sender.sendMessage("§e/teamadmin resetall       §7<team> - Reset all data");
        sender.sendMessage("§e/teamadmin list           §7       - List all teams");
        sender.sendMessage("§8§m---------------------------------");
    }

    private List<String> filterPrefix(String prefix, String... options) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return Arrays.stream(options)
            .filter(o -> o.startsWith(lower))
            .collect(Collectors.toList());
    }
}
