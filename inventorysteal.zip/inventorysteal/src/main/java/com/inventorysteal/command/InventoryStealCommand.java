package com.inventorysteal.command;

import com.inventorysteal.InventoryStealPlugin;
import com.inventorysteal.config.MessagesManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Handles the {@code /inventorysteal} (alias: {@code /is}) root command.
 *
 * <pre>
 * /inventorysteal reload  — reload config and messages
 * /inventorysteal info    — show plugin info
 * /inventorysteal version — show version
 * </pre>
 */
public class InventoryStealCommand implements CommandExecutor, TabCompleter {

    private final InventoryStealPlugin plugin;
    private final MessagesManager messages;

    public InventoryStealCommand(InventoryStealPlugin plugin, MessagesManager messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (args.length == 0) {
            sendInfo(sender);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                if (!sender.hasPermission("inventorysteal.reload")) {
                    sender.sendMessage(messages.getRaw("general.no-permission"));
                    return true;
                }
                plugin.reloadConfig();
                plugin.getConfigManager().reload();
                plugin.getMessagesManager().reload();
                if (plugin.getConfigManager().isHeartRecipeEnabled()) {
                    plugin.getHeartRecipe().register();
                } else {
                    plugin.getHeartRecipe().unregister();
                }
                sender.sendMessage(messages.get("general.reload-success"));
            }
            case "info", "version" -> sendInfo(sender);
            default -> sendInfo(sender);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (args.length == 1) {
            return filterPrefix(args[0], "reload", "info", "version");
        }
        return Collections.emptyList();
    }

    private void sendInfo(CommandSender sender) {
        sender.sendMessage("§8§m---§r §6InventorySteal §8v" + plugin.getDescription().getVersion() + " §8§m---");
        sender.sendMessage("§7Team-based shared inventory plugin for PaperMC.");
        sender.sendMessage("§7Use §e/team help§7 for player commands.");
        sender.sendMessage("§7Use §e/teamadmin§7 for admin commands.");
        sender.sendMessage("§7Reload config: §e/is reload");
        sender.sendMessage("§8§m-----------------------------------");
    }

    private List<String> filterPrefix(String prefix, String... options) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return Arrays.stream(options)
            .filter(o -> o.startsWith(lower))
            .collect(Collectors.toList());
    }
}
