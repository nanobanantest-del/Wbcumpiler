package com.inventorysteal.command;

import com.inventorysteal.config.MessagesManager;
import com.inventorysteal.manager.SharedInventoryManager;
import com.inventorysteal.manager.TeamManager;
import com.inventorysteal.model.PendingInvite;
import com.inventorysteal.model.Team;
import com.inventorysteal.service.HealthSyncService;
import com.inventorysteal.service.InventorySyncService;
import com.inventorysteal.service.TeamService;
import com.inventorysteal.service.TeamService.Result;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Handles all {@code /team} subcommands.
 *
 * <pre>
 * /team create  &lt;name&gt;
 * /team invite  &lt;player&gt;
 * /team accept  &lt;team&gt;
 * /team join    &lt;team&gt;   (same as accept — alias)
 * /team leave
 * /team kick    &lt;player&gt;
 * /team disband
 * /team info    [team]
 * /team list
 * /team storage
 * </pre>
 */
public class TeamCommand implements CommandExecutor, TabCompleter {

    private final TeamManager teamManager;
    private final SharedInventoryManager sharedInvManager;
    private final TeamService teamService;
    private final InventorySyncService inventorySyncService;
    private final HealthSyncService healthSyncService;
    private final MessagesManager messages;

    public TeamCommand(TeamManager teamManager,
                       SharedInventoryManager sharedInvManager,
                       TeamService teamService,
                       InventorySyncService inventorySyncService,
                       HealthSyncService healthSyncService,
                       MessagesManager messages) {
        this.teamManager = teamManager;
        this.sharedInvManager = sharedInvManager;
        this.teamService = teamService;
        this.inventorySyncService = inventorySyncService;
        this.healthSyncService = healthSyncService;
        this.messages = messages;
    }

    // -------------------------------------------------------------------------
    // Command dispatch
    // -------------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.getRaw("general.player-only"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create"  -> handleCreate(player, args);
            case "invite"  -> handleInvite(player, args);
            case "accept", "join" -> handleAccept(player, args);
            case "leave"   -> handleLeave(player);
            case "kick"    -> handleKick(player, args);
            case "disband" -> handleDisband(player);
            case "info"    -> handleInfo(player, args);
            case "list"    -> handleList(player);
            case "storage" -> handleStorage(player);
            case "help"    -> sendHelp(player);
            default        -> player.sendMessage(
                messages.format("general.unknown-command", Map.of("command", label)));
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Subcommand handlers
    // -------------------------------------------------------------------------

    private void handleCreate(Player player, String[] args) {
        if (!player.hasPermission("inventorysteal.team.create")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        if (args.length < 2) { player.sendMessage(usage("create <name>")); return; }

        Result result = teamService.createTeam(player, args[1]);
        sendResult(player, result, "create", args[1], null);
    }

    private void handleInvite(Player player, String[] args) {
        if (!player.hasPermission("inventorysteal.team.invite")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        if (args.length < 2) { player.sendMessage(usage("invite <player>")); return; }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage(messages.format("general.player-not-found", Map.of("player", args[1])));
            return;
        }

        Result result = teamService.invitePlayer(player, target);
        sendResult(player, result, "invite", null, target.getName());
    }

    private void handleAccept(Player player, String[] args) {
        if (!player.hasPermission("inventorysteal.team.accept")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        if (args.length < 2) { player.sendMessage(usage("accept <team>")); return; }

        Result result = teamService.acceptInvite(player, args[1]);
        sendResult(player, result, "accept", args[1], null);
    }

    private void handleLeave(Player player) {
        if (!player.hasPermission("inventorysteal.team.leave")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) { player.sendMessage(messages.get("team.not-in-team")); return; }
        if (team.isLeader(player.getUniqueId())) {
            player.sendMessage(messages.get("team.leader-cannot-leave")); return;
        }
        Result result = teamService.leaveTeam(player);
        if (result == Result.ON_COOLDOWN) {
            long remaining = teamService.remainingCooldown(
                player.getUniqueId(), "leave", 60);
            player.sendMessage(messages.format("general.on-cooldown",
                Map.of("seconds", String.valueOf(remaining))));
        }
    }

    private void handleKick(Player player, String[] args) {
        if (!player.hasPermission("inventorysteal.team.kick")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        if (args.length < 2) { player.sendMessage(usage("kick <player>")); return; }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            player.sendMessage(messages.format("general.player-not-found", Map.of("player", args[1])));
            return;
        }
        Result result = teamService.kickMember(player, target);
        sendResult(player, result, "kick", null, target.getName());
    }

    private void handleDisband(Player player) {
        if (!player.hasPermission("inventorysteal.team.disband")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        Result result = teamService.disbandTeam(player);
        if (result == Result.ON_COOLDOWN) {
            long remaining = teamService.remainingCooldown(
                player.getUniqueId(), "disband", 120);
            player.sendMessage(messages.format("general.on-cooldown",
                Map.of("seconds", String.valueOf(remaining))));
        } else if (result == Result.NOT_LEADER) {
            player.sendMessage(messages.get("team.not-leader"));
        } else if (result == Result.NOT_IN_TEAM) {
            player.sendMessage(messages.get("team.not-in-team"));
        }
    }

    private void handleInfo(Player player, String[] args) {
        if (!player.hasPermission("inventorysteal.team.info")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }

        Team team;
        if (args.length >= 2) {
            team = teamManager.getTeamByName(args[1]);
        } else {
            team = teamManager.getTeamByMember(player.getUniqueId());
        }

        if (team == null) {
            player.sendMessage(messages.format("team.team-not-found",
                Map.of("team", args.length >= 2 ? args[1] : "your team")));
            return;
        }

        // Build member list
        String memberList = team.getMembers().stream()
            .map(uuid -> {
                Player p = Bukkit.getPlayer(uuid);
                String name = p != null ? p.getName() : uuid.toString().substring(0, 8) + "...";
                return (team.isLeader(uuid) ? "§6" : "§f") + name;
            })
            .collect(Collectors.joining("§7, "));

        String maxSize = "0".equals(String.valueOf(
            team.getMembers().size())) ? "∞" : "∞";

        int hearts = (int) (team.getMaxHealthBonus() / 2);
        player.sendMessage(messages.format("team.info-header",
            Map.of("team", team.getName())));
        player.sendMessage(messages.format("team.info-leader",
            Map.of("leader", nameOf(team.getLeaderId()))));
        player.sendMessage(messages.format("team.info-members",
            Map.of("count", String.valueOf(team.getMemberCount()),
                   "max", "∞",
                   "members", memberList)));
        player.sendMessage(messages.format("team.info-storage",
            Map.of("slots", String.valueOf(team.getStorageSlots()))));
        player.sendMessage(messages.format("team.info-health-bonus",
            Map.of("bonus", String.valueOf(team.getMaxHealthBonus()),
                   "hearts", String.valueOf(hearts))));
        player.sendMessage(messages.getRaw("team.info-footer"));
    }

    private void handleList(Player player) {
        if (!player.hasPermission("inventorysteal.team.list")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        Collection<Team> teams = teamManager.getAllTeams();
        player.sendMessage(messages.format("team.list-header",
            Map.of("count", String.valueOf(teams.size()))));
        if (teams.isEmpty()) {
            player.sendMessage(messages.get("team.list-empty"));
        } else {
            for (Team team : teams) {
                player.sendMessage(messages.format("team.list-entry", Map.of(
                    "team", team.getName(),
                    "count", String.valueOf(team.getMemberCount()),
                    "max", "∞",
                    "leader", nameOf(team.getLeaderId())
                )));
            }
        }
    }

    private void handleStorage(Player player) {
        if (!player.hasPermission("inventorysteal.team.storage")) {
            player.sendMessage(messages.getRaw("general.no-permission")); return;
        }
        Team team = teamManager.getTeamByMember(player.getUniqueId());
        if (team == null) { player.sendMessage(messages.get("team.not-in-team")); return; }
        sharedInvManager.openStorage(player, team);
    }

    // -------------------------------------------------------------------------
    // Tab completion
    // -------------------------------------------------------------------------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (!(sender instanceof Player)) return Collections.emptyList();

        if (args.length == 1) {
            return filterPrefix(args[0], "create", "invite", "accept", "join",
                "leave", "kick", "disband", "info", "list", "storage", "help");
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase(Locale.ROOT)) {
                case "invite", "kick" -> Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
                case "accept", "join" -> teamManager.getAllTeams().stream()
                    .map(Team::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
                case "info" -> teamManager.getAllTeams().stream()
                    .map(Team::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
                default -> Collections.emptyList();
            };
        }
        return Collections.emptyList();
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void sendResult(Player player, Result result, String action,
                            String teamName, String targetName) {
        String team = teamName != null ? teamName : "";
        String target = targetName != null ? targetName : "";
        switch (result) {
            case ALREADY_IN_TEAM    -> player.sendMessage(messages.get("team.already-in-team"));
            case NOT_IN_TEAM        -> player.sendMessage(messages.get("team.not-in-team"));
            case NOT_LEADER         -> player.sendMessage(messages.get("team.not-leader"));
            case TEAM_FULL          -> player.sendMessage(messages.format("team.team-full",
                Map.of("team", team, "max", "∞")));
            case TEAM_NOT_FOUND     -> player.sendMessage(messages.format("team.team-not-found",
                Map.of("team", team)));
            case NAME_TAKEN         -> player.sendMessage(messages.get("team.name-taken"));
            case NAME_INVALID       -> player.sendMessage(messages.get("team.name-invalid"));
            case ALREADY_INVITED    -> player.sendMessage(messages.format("team.already-invited",
                Map.of("player", target)));
            case INVITE_NOT_FOUND   -> player.sendMessage(messages.format("team.invite-not-found",
                Map.of("team", team)));
            case KICK_SELF          -> player.sendMessage(messages.get("team.kick-self"));
            case KICK_NOT_MEMBER    -> player.sendMessage(messages.format("team.kick-not-member",
                Map.of("player", target)));
            case ON_COOLDOWN        -> player.sendMessage(messages.get("general.on-cooldown"));
            default -> {} // SUCCESS handled by TeamService
        }
    }

    private void sendHelp(Player player) {
        player.sendMessage("§8§m----------§r §6/team §8§m----------");
        player.sendMessage("§e/team create §7<name>     §f- Create a team");
        player.sendMessage("§e/team invite §7<player>   §f- Invite a player");
        player.sendMessage("§e/team accept §7<team>     §f- Accept an invite");
        player.sendMessage("§e/team leave               §f- Leave your team");
        player.sendMessage("§e/team kick §7<player>     §f- Kick a member");
        player.sendMessage("§e/team disband             §f- Disband your team");
        player.sendMessage("§e/team info §7[team]       §f- View team info");
        player.sendMessage("§e/team list                §f- List all teams");
        player.sendMessage("§e/team storage             §f- Open team storage");
        player.sendMessage("§8§m-------------------------------");
    }

    private String usage(String sub) {
        return "§cUsage: §e/team " + sub;
    }

    private String nameOf(java.util.UUID uuid) {
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) return p.getName();
        // Fall back to last-known name via OfflinePlayer
        org.bukkit.OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
        return op.getName() != null ? op.getName() : uuid.toString().substring(0, 8) + "...";
    }

    private List<String> filterPrefix(String prefix, String... options) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return Arrays.stream(options)
            .filter(o -> o.startsWith(lower))
            .collect(Collectors.toList());
    }
}
