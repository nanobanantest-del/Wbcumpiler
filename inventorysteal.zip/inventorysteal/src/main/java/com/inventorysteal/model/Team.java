package com.inventorysteal.model;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Represents a player team in InventorySteal.
 *
 * <p>Each team holds:
 * <ul>
 *   <li>A unique ID and display name</li>
 *   <li>A reference to the leader's UUID</li>
 *   <li>A list of member UUIDs (includes leader)</li>
 *   <li>The canonical synced player-inventory (main + armor + offhand)</li>
 *   <li>The shared ender-chest contents</li>
 *   <li>The team chest-storage contents (upgradeable)</li>
 *   <li>Storage size and max-health bonus metadata</li>
 * </ul>
 */
public class Team {

    /** Stable identifier for this team — never changes. */
    private final UUID id;

    /** Human-readable display name chosen at creation. */
    private String name;

    /** UUID of the current team leader. */
    private UUID leaderId;

    /** All member UUIDs, including the leader. */
    private final List<UUID> members;

    /** Pending invites keyed by the invited player's UUID. */
    private final Map<UUID, PendingInvite> pendingInvites;

    /**
     * The canonical player-inventory shared by all teammates.
     * Index layout mirrors {@link org.bukkit.entity.HumanEntity#getInventory()}:
     * slots 0-35 = main inventory (0-8 hotbar), 36-39 = armor, 40 = offhand.
     */
    private ItemStack[] canonicalInventory;

    /** Shared ender-chest contents (27 slots). */
    private ItemStack[] sharedEnderChest;

    /** Team chest-storage contents (variable size). */
    private ItemStack[] teamStorage;

    /** Current number of slots in the team chest-storage. */
    private int storageSlots;

    /**
     * Accumulated max-health bonus in HP (2 HP = 1 heart).
     * Applied to every online team member via an attribute modifier.
     */
    private double maxHealthBonus;

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * Create a brand-new team with default values.
     *
     * @param id           stable team UUID
     * @param name         display name
     * @param leaderId     UUID of the founding leader
     * @param storageSlots initial team-storage slot count
     */
    public Team(UUID id, String name, UUID leaderId, int storageSlots) {
        this.id = id;
        this.name = name;
        this.leaderId = leaderId;
        this.members = new ArrayList<>();
        this.pendingInvites = new HashMap<>();
        this.storageSlots = storageSlots;
        this.maxHealthBonus = 0.0;
        this.canonicalInventory = new ItemStack[41];
        this.sharedEnderChest = new ItemStack[27];
        this.teamStorage = new ItemStack[storageSlots];
    }

    /**
     * Reconstruct a team loaded from persistent storage.
     *
     * @param id             stable team UUID
     * @param name           display name
     * @param leaderId       UUID of the current leader
     * @param members        list of member UUIDs
     * @param storageSlots   current storage slot count
     * @param maxHealthBonus accumulated health bonus in HP
     */
    public Team(UUID id, String name, UUID leaderId, List<UUID> members,
                int storageSlots, double maxHealthBonus) {
        this.id = id;
        this.name = name;
        this.leaderId = leaderId;
        this.members = new ArrayList<>(members);
        this.pendingInvites = new HashMap<>();
        this.storageSlots = storageSlots;
        this.maxHealthBonus = maxHealthBonus;
        this.canonicalInventory = new ItemStack[41];
        this.sharedEnderChest = new ItemStack[27];
        this.teamStorage = new ItemStack[storageSlots];
    }

    // -------------------------------------------------------------------------
    // Member management helpers
    // -------------------------------------------------------------------------

    /** @return {@code true} if {@code playerUUID} is a member of this team. */
    public boolean isMember(UUID playerUUID) {
        return members.contains(playerUUID);
    }

    /** @return {@code true} if {@code playerUUID} is the team leader. */
    public boolean isLeader(UUID playerUUID) {
        return leaderId.equals(playerUUID);
    }

    /**
     * Add a member.  No-op if already present.
     *
     * @param playerUUID UUID to add
     */
    public void addMember(UUID playerUUID) {
        if (!members.contains(playerUUID)) {
            members.add(playerUUID);
        }
    }

    /**
     * Remove a member.
     *
     * @param playerUUID UUID to remove
     * @return {@code true} if the member was present and removed
     */
    public boolean removeMember(UUID playerUUID) {
        return members.remove(playerUUID);
    }

    /** @return current member count */
    public int getMemberCount() {
        return members.size();
    }

    // -------------------------------------------------------------------------
    // Invite helpers
    // -------------------------------------------------------------------------

    /**
     * Check whether a player has a pending invite.
     *
     * @param playerUUID target player
     * @return {@code true} if there is an unexpired invite
     */
    public boolean hasPendingInvite(UUID playerUUID) {
        return pendingInvites.containsKey(playerUUID);
    }

    /**
     * Add or replace a pending invite.
     *
     * @param invite invite to store
     */
    public void addPendingInvite(PendingInvite invite) {
        pendingInvites.put(invite.getInvitedPlayer(), invite);
    }

    /**
     * Remove a pending invite.
     *
     * @param playerUUID target player
     */
    public void removePendingInvite(UUID playerUUID) {
        pendingInvites.remove(playerUUID);
    }

    // -------------------------------------------------------------------------
    // Getters / Setters
    // -------------------------------------------------------------------------

    public UUID getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public UUID getLeaderId() { return leaderId; }
    public void setLeaderId(UUID leaderId) { this.leaderId = leaderId; }

    public List<UUID> getMembers() { return members; }

    public Map<UUID, PendingInvite> getPendingInvites() { return pendingInvites; }

    public ItemStack[] getCanonicalInventory() { return canonicalInventory; }
    public void setCanonicalInventory(ItemStack[] canonicalInventory) {
        this.canonicalInventory = canonicalInventory;
    }

    public ItemStack[] getSharedEnderChest() { return sharedEnderChest; }
    public void setSharedEnderChest(ItemStack[] sharedEnderChest) {
        this.sharedEnderChest = sharedEnderChest;
    }

    public ItemStack[] getTeamStorage() { return teamStorage; }
    public void setTeamStorage(ItemStack[] teamStorage) {
        this.teamStorage = teamStorage;
    }

    public int getStorageSlots() { return storageSlots; }

    /**
     * Directly set the storage slot count and reset the storage array.
     * Use for admin resets; for upgrades prefer {@link #expandStorage}.
     *
     * @param slots new slot count
     */
    public void resetStorage(int slots) {
        this.storageSlots = slots;
        this.teamStorage = new ItemStack[slots];
    }

    /**
     * Expand team storage to a new slot count.  Existing items are preserved.
     *
     * @param newSlots new total slot count (must be &gt; current)
     */
    public void expandStorage(int newSlots) {
        if (newSlots <= storageSlots) return;
        ItemStack[] expanded = new ItemStack[newSlots];
        System.arraycopy(teamStorage, 0, expanded, 0, teamStorage.length);
        this.teamStorage = expanded;
        this.storageSlots = newSlots;
    }

    public double getMaxHealthBonus() { return maxHealthBonus; }
    public void setMaxHealthBonus(double maxHealthBonus) {
        this.maxHealthBonus = maxHealthBonus;
    }

    @Override
    public String toString() {
        return "Team{id=" + id + ", name='" + name + "', leader=" + leaderId
                + ", members=" + members.size() + '}';
    }
}
