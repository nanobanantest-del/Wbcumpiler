package com.inventorysteal.model;

import java.time.Instant;
import java.util.UUID;

/**
 * Represents a pending team invitation.
 *
 * <p>Invites expire after a configurable timeout.  The expiry is calculated
 * at creation time so that it can be checked without needing the config object.
 */
public class PendingInvite {

    /** Team the invitation is for. */
    private final UUID teamId;

    /** Player who was invited. */
    private final UUID invitedPlayer;

    /** Player who sent the invitation. */
    private final UUID invitedBy;

    /** Absolute instant at which this invite expires. */
    private final Instant expiresAt;

    /**
     * Create a new pending invite.
     *
     * @param teamId        team UUID
     * @param invitedPlayer UUID of the player being invited
     * @param invitedBy     UUID of the player who sent the invite
     * @param timeoutSeconds seconds until the invite expires
     */
    public PendingInvite(UUID teamId, UUID invitedPlayer, UUID invitedBy, int timeoutSeconds) {
        this.teamId = teamId;
        this.invitedPlayer = invitedPlayer;
        this.invitedBy = invitedBy;
        this.expiresAt = Instant.now().plusSeconds(timeoutSeconds);
    }

    /**
     * Reconstruct an invite from persistent storage.
     *
     * @param teamId        team UUID
     * @param invitedPlayer invited player UUID
     * @param invitedBy     sender UUID
     * @param expiresAt     absolute expiry instant
     */
    public PendingInvite(UUID teamId, UUID invitedPlayer, UUID invitedBy, Instant expiresAt) {
        this.teamId = teamId;
        this.invitedPlayer = invitedPlayer;
        this.invitedBy = invitedBy;
        this.expiresAt = expiresAt;
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * @return {@code true} if the invite has passed its expiry time
     */
    public boolean isExpired() {
        return Instant.now().isAfter(expiresAt);
    }

    /**
     * @return remaining seconds until expiry, or 0 if already expired
     */
    public long remainingSeconds() {
        long remaining = expiresAt.getEpochSecond() - Instant.now().getEpochSecond();
        return Math.max(0, remaining);
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public UUID getTeamId() { return teamId; }
    public UUID getInvitedPlayer() { return invitedPlayer; }
    public UUID getInvitedBy() { return invitedBy; }
    public Instant getExpiresAt() { return expiresAt; }

    @Override
    public String toString() {
        return "PendingInvite{team=" + teamId + ", invited=" + invitedPlayer
                + ", by=" + invitedBy + ", expires=" + expiresAt + '}';
    }
}
