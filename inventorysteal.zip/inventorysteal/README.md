# InventorySteal

A production-ready PaperMC plugin where every player on a team shares **everything**: inventory, armor, health, hunger, potion effects, and more.

## Features

| Feature | Description |
|---|---|
| **Shared Inventory** | All teammates share one canonical inventory — main, hotbar, armor, offhand |
| **Shared Ender Chest** | One ender chest for the whole team |
| **Team Storage** | Upgradeable chest GUI (27→54→81→108+ slots) using Dragon Eggs |
| **Health Sync** | Damage, healing, hunger, saturation, air, and fire ticks all sync instantly |
| **Potion Sync** | All potion effects (including milk-clear) propagate to every teammate |
| **Team Death** | One death = whole team dies, inventories drop, shared state is cleared |
| **Heart Upgrade** | Custom crafting recipe to permanently add +1 heart (2 HP) to the team |
| **SQLite / MySQL** | Choose your database in `config.yml` |
| **SOLID Architecture** | Services, managers, repositories, listeners — fully separated concerns |

---

## Requirements

| Requirement | Version |
|---|---|
| Java | 21+ |
| Paper / Folia | 1.20.x – 1.21.x |
| Gradle | 8.7+ |

---

## Building

### Prerequisites

| Requirement | Version |
|---|---|
| Gradle | **8.7+** — used to generate the wrapper on first clone |
| Java JDK | **21** — required by Paper API 1.20.6 |

> **Note:** The `gradle-wrapper.jar` binary is not stored in git (it's a binary blob).
> You must generate it once with a local Gradle 8.7+ install.

### Step 1 — Generate the Gradle wrapper (one-time, per machine)

```bash
cd inventorysteal
gradle wrapper --gradle-version=8.7
```

This creates `gradle/wrapper/gradle-wrapper.jar` and `gradlew`.

### Step 2 — Build the plugin

```bash
./gradlew shadowJar
```

### Output

```
inventorysteal/build/libs/InventorySteal-1.0.0.jar  (~18 MB with shaded deps)
```

Drop it in your server's `plugins/` folder.

### Shadow / shading notes

This project uses **`io.github.goooler.shadow` 8.1.8** — a community-maintained
fork of the popular Shadow plugin. The original `com.github.johnrengelman.shadow`
8.1.1 ships an ASM version that cannot remap Java 21 class files during
relocation. The Goooler fork ships ASM 9.7 which fully supports Java 21 bytecode.

**SQLite JDBC is intentionally NOT relocated.** The driver bundles architecture-specific
native libraries (`.so` / `.dll` / `.dylib`) that are loaded by the JNI subsystem
using the original `org/sqlite/…` class path. Relocating the package to
`com.inventorysteal.libs.sqlite` moves the Java classes but not the native
bindings, causing `UnsatisfiedLinkError: NativeDB._open_utf8` at startup.

**SLF4J is intentionally NOT relocated.** The Paper server provides its own SLF4J
implementation. Shading a second copy causes a `StaticLoggerBinder` conflict.
HikariCP's logging simply uses whatever SLF4J binding the server supplies.

---

## Installation

1. Build the JAR (see above).
2. Copy `InventorySteal-1.0.0.jar` to your server's `plugins/` folder.
3. Start the server — default `config.yml` and `messages.yml` are auto-generated in `plugins/InventorySteal/`.
4. Edit `config.yml` (database, team size, sync options, etc.) and run `/is reload`.

---

## Commands

### Player commands (`/team`)

| Command | Permission | Description |
|---|---|---|
| `/team create <name>` | `inventorysteal.team.create` | Create a team |
| `/team invite <player>` | `inventorysteal.team.invite` | Invite a player |
| `/team accept <team>` | `inventorysteal.team.accept` | Accept an invitation |
| `/team leave` | `inventorysteal.team.leave` | Leave your team |
| `/team kick <player>` | `inventorysteal.team.kick` | Kick a member |
| `/team disband` | `inventorysteal.team.disband` | Disband your team |
| `/team info [team]` | `inventorysteal.team.info` | View team details |
| `/team list` | `inventorysteal.team.list` | List all teams |
| `/team storage` | `inventorysteal.team.storage` | Open team chest storage |

### Admin commands (`/teamadmin`)

| Command | Permission | Description |
|---|---|---|
| `/teamadmin delete <team>` | `inventorysteal.teamadmin` | Force-delete a team |
| `/teamadmin resetinventory <team>` | `inventorysteal.teamadmin` | Clear all inventories |
| `/teamadmin resethearts <team>` | `inventorysteal.teamadmin` | Reset heart upgrades |
| `/teamadmin resetupgrades <team>` | `inventorysteal.teamadmin` | Reset storage upgrades |
| `/teamadmin resetall <team>` | `inventorysteal.teamadmin` | Reset everything |
| `/teamadmin list` | `inventorysteal.teamadmin` | List all teams |

### Plugin management (`/inventorysteal` / `/is`)

| Command | Permission | Description |
|---|---|---|
| `/is reload` | `inventorysteal.reload` | Reload config + messages |
| `/is info` | — | Show plugin info |

---

## Heart Upgrade Recipe

Craft a **Heart** item to permanently increase your team's max health by +1 heart (+2 HP):

```
[ Gold Block  ] [ Gold Block  ] [ Gold Block  ]
[ Dia. Block  ] [   Beacon    ] [ Dia. Block  ]
[ Neth. Block ] [ Neth. Block ] [ Neth. Block ]
```

Right-click to consume. The bonus applies to every online team member immediately and is saved permanently.

---

## Storage Upgrade

Open your team storage with `/team storage`. To upgrade:

1. Hold a **Dragon Egg** in your main hand.
2. Right-click the storage GUI (or use a future `/team upgrade` command — see config).

Each Dragon Egg consumed adds 27 slots (configurable via `inventory.slots-per-upgrade` in `config.yml`).

---

## Configuration

Key settings in `config.yml`:

```yaml
database:
  type: sqlite   # or mysql

team:
  max-size: 10
  invite-timeout: 60

inventory:
  default-storage-slots: 27
  slots-per-upgrade: 27
  upgrade-item: DRAGON_EGG

health:
  max-health-bonus: 0   # 0 = unlimited

death:
  team-death: true
  drop-inventories: true
  clear-shared-inventory: true

heart:
  recipe-enabled: true
  hp-per-heart: 2.0
```

All player-facing strings live in `messages.yml`.

---

## Architecture

```
com.inventorysteal
├── InventoryStealPlugin       Main JavaPlugin — wires all components
├── config/
│   ├── ConfigManager          Typed wrapper over config.yml
│   └── MessagesManager        Loads & caches messages.yml with placeholder support
├── data/
│   ├── Database               Interface (CRUD for teams, members, invites, inventories)
│   ├── SQLiteDatabase         JDBC SQLite implementation (WAL mode)
│   └── MySQLDatabase          HikariCP MySQL implementation
├── model/
│   ├── Team                   Domain object (members, canonical inventory, upgrades)
│   └── PendingInvite          Invite with expiry
├── repository/
│   ├── TeamRepository         Façade over Database for team/member/invite CRUD
│   └── InventoryRepository    Serialises/deserialises ItemStack arrays to/from DB
├── manager/
│   ├── TeamManager            In-memory cache (3 indexes) + persistence delegation
│   └── SharedInventoryManager Storage GUI lifecycle + syncing-lock set
├── service/
│   ├── TeamService            Business logic (create, invite, accept, leave, kick, disband)
│   ├── InventorySyncService   Capture + push canonical inventory to teammates
│   ├── HealthSyncService      Health, hunger, air, fire-tick sync + attribute modifiers
│   └── DeathService           Team-death cascade (kill all, drop items, clear state)
├── listener/
│   ├── InventoryListener      All inventory mutation events → scheduleInventorySync
│   ├── PlayerListener         Login/logout, damage, food, respawn
│   ├── DeathListener          PlayerDeathEvent → DeathService cascade
│   └── PotionListener         Potion effect apply/remove/clear propagation
├── command/
│   ├── TeamCommand            /team with full tab completion
│   ├── TeamAdminCommand       /teamadmin with full tab completion
│   └── InventoryStealCommand  /is reload|info|version
├── recipe/
│   └── HeartRecipe            Shaped recipe registration + right-click consume
└── util/
    ├── SerializationUtil      ItemStack[] ↔ Base64 via BukkitObjectOutputStream
    └── ItemUtil               Item creation, colour codes, array helpers
```

---

## Performance Notes

- **No async Bukkit API calls.** All inventory and entity operations run on the main thread.
- **In-memory cache.** Three indexes (`byId`, `byName`, `byMember`) allow O(1) team lookups.
- **Syncing lock.** A `Set<UUID>` prevents recursive inventory-change loops when pushing to teammates.
- **One-tick defer.** Inventory syncs are scheduled on the next tick so Bukkit has committed the change before we read it.
- **Connection pool.** MySQL uses HikariCP with configurable pool size.
- **WAL mode.** SQLite uses Write-Ahead Logging for better read concurrency.

---

## License

MIT — use freely, no warranty.
