/**
 * Minecraft Plugin Compiler — Backend Server
 * Receives a ZIP of plugin source, detects Maven/Gradle, compiles, returns JAR.
 */

const express  = require('express');
const multer   = require('multer');
const AdmZip   = require('adm-zip');
const path     = require('path');
const fs       = require('fs');
const { exec, spawn } = require('child_process');
const { v4: uuidv4 }  = require('uuid');
const cors     = require('cors');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Directories ───────────────────────────────────────────────────────────────
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const OUTPUT_DIR  = path.join(__dirname, 'output');
const WORK_DIR    = path.join(__dirname, 'workspaces');

[UPLOADS_DIR, OUTPUT_DIR, WORK_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Serve output JARs for download
app.use('/download', express.static(OUTPUT_DIR));

// ── Multer (file upload) ──────────────────────────────────────────────────────
const storage = multer.diskStorage({
    destination: UPLOADS_DIR,
    filename: (req, file, cb) => cb(null, uuidv4() + '_' + file.originalname)
});

const upload = multer({
    storage,
    limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB max
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/zip' ||
            file.originalname.endsWith('.zip')) {
            cb(null, true);
        } else {
            cb(new Error('Only .zip files are allowed'));
        }
    }
});

// ── Active jobs store (in-memory) ────────────────────────────────────────────
const jobs = new Map();
// job shape: { id, status, log, jarName, error, startedAt }

// ── Helpers ───────────────────────────────────────────────────────────────────

function log(jobId, line) {
    const job = jobs.get(jobId);
    if (job) {
        job.log += line + '\n';
        console.log(`[${jobId.slice(0,8)}] ${line}`);
    }
}

function detectBuildTool(dir) {
    if (fs.existsSync(path.join(dir, 'pom.xml')))        return 'maven';
    if (fs.existsSync(path.join(dir, 'build.gradle')))   return 'gradle';
    if (fs.existsSync(path.join(dir, 'build.gradle.kts'))) return 'gradle';
    return null;
}

/**
 * Find the project root inside the extracted workspace.
 * Some ZIPs have a top-level folder, others dump files directly.
 */
function findProjectRoot(workDir) {
    // Check if pom.xml/build.gradle is directly in workDir
    if (detectBuildTool(workDir)) return workDir;

    // Check one level down
    const entries = fs.readdirSync(workDir);
    for (const entry of entries) {
        const sub = path.join(workDir, entry);
        if (fs.statSync(sub).isDirectory()) {
            if (detectBuildTool(sub)) return sub;
        }
    }
    return null;
}

/**
 * Find the compiled JAR in target/ or build/libs/
 */
function findJar(projectRoot, buildTool) {
    const candidates = buildTool === 'maven'
        ? [path.join(projectRoot, 'target')]
        : [path.join(projectRoot, 'build', 'libs')];

    for (const dir of candidates) {
        if (!fs.existsSync(dir)) continue;
        const jars = fs.readdirSync(dir)
            .filter(f => f.endsWith('.jar') && !f.includes('original') && !f.includes('sources'));
        if (jars.length > 0) return path.join(dir, jars[0]);
    }
    return null;
}

/**
 * Run a command with live log streaming.
 */
function runCommand(cmd, args, cwd, jobId, env = {}) {
    return new Promise((resolve, reject) => {
        const mergedEnv = { ...process.env, ...env };
        const proc = spawn(cmd, args, { cwd, env: mergedEnv, shell: true });

        proc.stdout.on('data', d => log(jobId, d.toString().trimEnd()));
        proc.stderr.on('data', d => log(jobId, d.toString().trimEnd()));

        proc.on('close', code => {
            if (code === 0) resolve();
            else reject(new Error(`Process exited with code ${code}`));
        });
        proc.on('error', reject);
    });
}

/**
 * Check if a tool is available on PATH.
 */
function checkTool(tool) {
    return new Promise(resolve => {
        exec(`${tool} --version`, (err) => resolve(!err));
    });
}

// ── Compile Job ───────────────────────────────────────────────────────────────

async function compilePlugin(jobId, zipPath) {
    const job = jobs.get(jobId);
    const workDir = path.join(WORK_DIR, jobId);
    fs.mkdirSync(workDir, { recursive: true });

    try {
        // 1. Extract ZIP
        log(jobId, '📦 Extracting ZIP archive...');
        const zip = new AdmZip(zipPath);
        zip.extractAllTo(workDir, true);
        log(jobId, '✅ Extraction complete.');

        // 2. Find project root
        const projectRoot = findProjectRoot(workDir);
        if (!projectRoot) {
            throw new Error('No pom.xml or build.gradle found in ZIP. Is this a valid Maven/Gradle project?');
        }
        log(jobId, `📁 Project root: ${path.relative(workDir, projectRoot) || './'}`);

        // 3. Detect build tool
        const buildTool = detectBuildTool(projectRoot);
        log(jobId, `🔧 Build tool detected: ${buildTool.toUpperCase()}`);
        job.buildTool = buildTool;

        // 4. Check tool availability
        if (buildTool === 'maven') {
            const hasMvn = await checkTool('mvn');
            if (!hasMvn) throw new Error('Maven (mvn) not found on server PATH. Install Maven 3.6+ on the server.');
            const hasJava = await checkTool('java');
            if (!hasJava) throw new Error('Java not found on server PATH. Install JDK 17+.');

            log(jobId, '☕ Running: mvn clean package -B --no-transfer-progress -DskipTests');
            job.status = 'building';

            await runCommand('mvn', [
                'clean', 'package',
                '-B',
                '--no-transfer-progress',
                '-DskipTests'
            ], projectRoot, jobId);

        } else if (buildTool === 'gradle') {
            // Try gradlew first, fall back to system gradle
            const gradlew = path.join(projectRoot, process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
            const useWrapper = fs.existsSync(gradlew);

            if (useWrapper) {
                // Make gradlew executable on Unix
                if (process.platform !== 'win32') {
                    fs.chmodSync(gradlew, '755');
                }
                log(jobId, '🐘 Running: ./gradlew clean build -x test');
                job.status = 'building';
                await runCommand(gradlew, ['clean', 'build', '-x', 'test', '--no-daemon'], projectRoot, jobId);
            } else {
                const hasGradle = await checkTool('gradle');
                if (!hasGradle) throw new Error('Gradle not found. ZIP must include a gradlew wrapper or Gradle must be installed on server.');
                log(jobId, '🐘 Running: gradle clean build -x test');
                job.status = 'building';
                await runCommand('gradle', ['clean', 'build', '-x', 'test', '--no-daemon'], projectRoot, jobId);
            }
        }

        // 5. Locate JAR
        log(jobId, '🔍 Locating compiled JAR...');
        const jarPath = findJar(projectRoot, buildTool);
        if (!jarPath) throw new Error('Build succeeded but no JAR found in output directory.');

        const jarName = `${jobId.slice(0, 8)}_${path.basename(jarPath)}`;
        const outputPath = path.join(OUTPUT_DIR, jarName);
        fs.copyFileSync(jarPath, outputPath);

        const sizeMb = (fs.statSync(outputPath).size / 1024 / 1024).toFixed(2);
        log(jobId, `✅ JAR compiled successfully! Size: ${sizeMb} MB`);
        log(jobId, `📥 Ready to download: ${path.basename(jarPath)}`);

        job.status  = 'done';
        job.jarName = jarName;
        job.jarOriginalName = path.basename(jarPath);
        job.sizeMb  = sizeMb;

    } catch (err) {
        log(jobId, `❌ COMPILE ERROR: ${err.message}`);
        job.status = 'error';
        job.error  = err.message;
    } finally {
        // Cleanup workspace and upload
        try { fs.rmSync(workDir,  { recursive: true, force: true }); } catch (_) {}
        try { fs.unlinkSync(zipPath); } catch (_) {}

        // Auto-delete output JAR after 30 minutes
        if (job.jarName) {
            const jarFile = path.join(OUTPUT_DIR, job.jarName);
            setTimeout(() => {
                try { fs.unlinkSync(jarFile); } catch (_) {}
            }, 30 * 60 * 1000);
        }
    }
}

// ── Routes ────────────────────────────────────────────────────────────────────

// Upload & start compile
app.post('/api/compile', upload.single('plugin'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    const jobId = uuidv4();
    jobs.set(jobId, {
        id:        jobId,
        status:    'extracting',
        log:       '',
        jarName:   null,
        error:     null,
        startedAt: Date.now()
    });

    // Fire-and-forget async compile
    compilePlugin(jobId, req.file.path).catch(console.error);

    res.json({ jobId });
});

// Poll job status
app.get('/api/status/:jobId', (req, res) => {
    const job = jobs.get(req.params.jobId);
    if (!job) return res.status(404).json({ error: 'Job not found' });

    res.json({
        status:          job.status,
        log:             job.log,
        jarName:         job.jarName,
        jarOriginalName: job.jarOriginalName,
        sizeMb:          job.sizeMb,
        error:           job.error,
        buildTool:       job.buildTool
    });
});

// Health check
app.get('/api/health', (req, res) => {
    Promise.all([checkTool('java'), checkTool('mvn'), checkTool('gradle')])
        .then(([java, maven, gradle]) => {
            res.json({ java, maven, gradle, status: 'ok' });
        });
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`\n🚀 Minecraft Plugin Compiler running at http://localhost:${PORT}`);
    console.log(`   Upload a plugin ZIP → get a compiled JAR\n`);
});
