# ⚙️ MC Plugin Compiler

Upload a Minecraft plugin ZIP → get a compiled JAR back.  
Supports **Maven** (`pom.xml`) and **Gradle** (`build.gradle` / `build.gradle.kts`).

---

## 🚀 Quick Start

### 1. Prerequisites (install on your server/machine)

| Tool | Minimum Version | Install |
|------|----------------|---------|
| Node.js | 18+ | https://nodejs.org |
| Java JDK | 17+ | https://adoptium.net |
| Maven | 3.6+ | `sudo apt install maven` or https://maven.apache.org |
| Gradle | 7+ (optional) | `sudo apt install gradle` (or use gradlew wrapper in ZIP) |

### 2. Install & Run

```bash
# Extract / clone this project
cd plugin-compiler

# Install Node dependencies
npm install

# Start the server
npm start
```

Open your browser at: **http://localhost:3000**

---

## 📁 Project Structure

```
plugin-compiler/
├── server.js          ← Express backend (compile logic)
├── package.json
├── public/
│   └── index.html     ← Full frontend UI
├── uploads/           ← Temp upload storage (auto-cleaned)
├── output/            ← Compiled JARs (auto-deleted after 30 min)
└── workspaces/        ← Build workspaces (auto-cleaned)
```

---

## 🔧 How It Works

1. You upload a `.zip` of your plugin source code
2. Server extracts the ZIP
3. Detects `pom.xml` → Maven, or `build.gradle` → Gradle
4. Runs `mvn clean package -DskipTests` or `./gradlew build -x test`
5. Finds the compiled `.jar` in `target/` or `build/libs/`
6. Serves it as a download — expires in 30 minutes

---

## 🌐 Deploying on a VPS / Server

```bash
# Install PM2 for background running
npm install -g pm2

# Start with PM2
pm2 start server.js --name plugin-compiler

# Auto-restart on reboot
pm2 startup
pm2 save
```

To use a custom port:
```bash
PORT=8080 npm start
```

Or put it behind Nginx:
```nginx
server {
    listen 80;
    server_name compiler.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        client_max_body_size 100M;
    }
}
```

---

## ⚠️ Notes

- **JARs expire after 30 minutes** — download immediately
- Max upload size: **100 MB**
- Maven downloads dependencies on first run (may take 1-2 min)
- Gradle projects with a `gradlew` wrapper work out of the box
- Tests are skipped during compilation for speed

---

## 🛠️ Troubleshooting

| Problem | Fix |
|---------|-----|
| `mvn: not found` | Install Maven: `sudo apt install maven` |
| `java: not found` | Install JDK 17: `sudo apt install openjdk-17-jdk` |
| Build fails with dependency error | Check internet access; Maven needs to download from repos |
| ZIP not recognized | Ensure your ZIP contains `pom.xml` or `build.gradle` at root or one level deep |
| Port 3000 in use | `PORT=8080 npm start` |
